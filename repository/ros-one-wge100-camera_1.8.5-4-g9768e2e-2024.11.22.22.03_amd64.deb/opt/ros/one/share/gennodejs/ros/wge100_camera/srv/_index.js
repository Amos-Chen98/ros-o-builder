
"use strict";

let BoardConfig = require('./BoardConfig.js')

module.exports = {
  BoardConfig: BoardConfig,
};
