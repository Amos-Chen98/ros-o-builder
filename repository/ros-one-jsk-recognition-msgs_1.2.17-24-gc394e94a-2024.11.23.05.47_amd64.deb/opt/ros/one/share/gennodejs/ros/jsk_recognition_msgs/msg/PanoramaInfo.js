// Auto-generated. Do not edit!

// (in-package jsk_recognition_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class PanoramaInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.projection_model = null;
      this.image_height = null;
      this.image_width = null;
      this.theta_min = null;
      this.theta_max = null;
      this.phi_min = null;
      this.phi_max = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('projection_model')) {
        this.projection_model = initObj.projection_model
      }
      else {
        this.projection_model = '';
      }
      if (initObj.hasOwnProperty('image_height')) {
        this.image_height = initObj.image_height
      }
      else {
        this.image_height = 0;
      }
      if (initObj.hasOwnProperty('image_width')) {
        this.image_width = initObj.image_width
      }
      else {
        this.image_width = 0;
      }
      if (initObj.hasOwnProperty('theta_min')) {
        this.theta_min = initObj.theta_min
      }
      else {
        this.theta_min = 0.0;
      }
      if (initObj.hasOwnProperty('theta_max')) {
        this.theta_max = initObj.theta_max
      }
      else {
        this.theta_max = 0.0;
      }
      if (initObj.hasOwnProperty('phi_min')) {
        this.phi_min = initObj.phi_min
      }
      else {
        this.phi_min = 0.0;
      }
      if (initObj.hasOwnProperty('phi_max')) {
        this.phi_max = initObj.phi_max
      }
      else {
        this.phi_max = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PanoramaInfo
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [projection_model]
    bufferOffset = _serializer.string(obj.projection_model, buffer, bufferOffset);
    // Serialize message field [image_height]
    bufferOffset = _serializer.uint32(obj.image_height, buffer, bufferOffset);
    // Serialize message field [image_width]
    bufferOffset = _serializer.uint32(obj.image_width, buffer, bufferOffset);
    // Serialize message field [theta_min]
    bufferOffset = _serializer.float64(obj.theta_min, buffer, bufferOffset);
    // Serialize message field [theta_max]
    bufferOffset = _serializer.float64(obj.theta_max, buffer, bufferOffset);
    // Serialize message field [phi_min]
    bufferOffset = _serializer.float64(obj.phi_min, buffer, bufferOffset);
    // Serialize message field [phi_max]
    bufferOffset = _serializer.float64(obj.phi_max, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PanoramaInfo
    let len;
    let data = new PanoramaInfo(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [projection_model]
    data.projection_model = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [image_height]
    data.image_height = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [image_width]
    data.image_width = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [theta_min]
    data.theta_min = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [theta_max]
    data.theta_max = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [phi_min]
    data.phi_min = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [phi_max]
    data.phi_max = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.projection_model);
    return length + 44;
  }

  static datatype() {
    // Returns string type for a message object
    return 'jsk_recognition_msgs/PanoramaInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '340435d77351bcae6fd5d846323c4a05';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # This message defines meta information for a panorama image.
    
    #######################################################################
    #                     Image acquisition info                          #
    #######################################################################
    std_msgs/Header header
    
    #######################################################################
    #                      Image projection info                          #
    #######################################################################
    string projection_model
    
    #######################################################################
    #                      Image shape info                               #
    #######################################################################
    uint32 image_height
    uint32 image_width
    
    #######################################################################
    #                     Field of View Parameters                        #
    #######################################################################
    float64 theta_min
    float64 theta_max
    float64 phi_min
    float64 phi_max
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PanoramaInfo(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.projection_model !== undefined) {
      resolved.projection_model = msg.projection_model;
    }
    else {
      resolved.projection_model = ''
    }

    if (msg.image_height !== undefined) {
      resolved.image_height = msg.image_height;
    }
    else {
      resolved.image_height = 0
    }

    if (msg.image_width !== undefined) {
      resolved.image_width = msg.image_width;
    }
    else {
      resolved.image_width = 0
    }

    if (msg.theta_min !== undefined) {
      resolved.theta_min = msg.theta_min;
    }
    else {
      resolved.theta_min = 0.0
    }

    if (msg.theta_max !== undefined) {
      resolved.theta_max = msg.theta_max;
    }
    else {
      resolved.theta_max = 0.0
    }

    if (msg.phi_min !== undefined) {
      resolved.phi_min = msg.phi_min;
    }
    else {
      resolved.phi_min = 0.0
    }

    if (msg.phi_max !== undefined) {
      resolved.phi_max = msg.phi_max;
    }
    else {
      resolved.phi_max = 0.0
    }

    return resolved;
    }
};

module.exports = PanoramaInfo;
