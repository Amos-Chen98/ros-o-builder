
"use strict";

let CheckCollision = require('./CheckCollision.js')
let SetLabels = require('./SetLabels.js')
let SetTemplate = require('./SetTemplate.js')
let SaveMesh = require('./SaveMesh.js')
let NonMaximumSuppression = require('./NonMaximumSuppression.js')
let CheckCircle = require('./CheckCircle.js')
let ICPAlign = require('./ICPAlign.js')
let PolygonOnEnvironment = require('./PolygonOnEnvironment.js')
let EnvironmentLock = require('./EnvironmentLock.js')
let UpdateOffset = require('./UpdateOffset.js')
let ICPAlignWithBox = require('./ICPAlignWithBox.js')
let WhiteBalancePoints = require('./WhiteBalancePoints.js')
let EuclideanSegment = require('./EuclideanSegment.js')
let SetDepthCalibrationParameter = require('./SetDepthCalibrationParameter.js')
let SetPointCloud2 = require('./SetPointCloud2.js')
let SnapFootstep = require('./SnapFootstep.js')
let SwitchTopic = require('./SwitchTopic.js')
let CallSnapIt = require('./CallSnapIt.js')
let TowerRobotMoveCommand = require('./TowerRobotMoveCommand.js')
let TransformScreenpoint = require('./TransformScreenpoint.js')
let TowerPickUp = require('./TowerPickUp.js')
let WhiteBalance = require('./WhiteBalance.js')
let RobotPickupReleasePoint = require('./RobotPickupReleasePoint.js')
let CallPolygon = require('./CallPolygon.js')

module.exports = {
  CheckCollision: CheckCollision,
  SetLabels: SetLabels,
  SetTemplate: SetTemplate,
  SaveMesh: SaveMesh,
  NonMaximumSuppression: NonMaximumSuppression,
  CheckCircle: CheckCircle,
  ICPAlign: ICPAlign,
  PolygonOnEnvironment: PolygonOnEnvironment,
  EnvironmentLock: EnvironmentLock,
  UpdateOffset: UpdateOffset,
  ICPAlignWithBox: ICPAlignWithBox,
  WhiteBalancePoints: WhiteBalancePoints,
  EuclideanSegment: EuclideanSegment,
  SetDepthCalibrationParameter: SetDepthCalibrationParameter,
  SetPointCloud2: SetPointCloud2,
  SnapFootstep: SnapFootstep,
  SwitchTopic: SwitchTopic,
  CallSnapIt: CallSnapIt,
  TowerRobotMoveCommand: TowerRobotMoveCommand,
  TransformScreenpoint: TransformScreenpoint,
  TowerPickUp: TowerPickUp,
  WhiteBalance: WhiteBalance,
  RobotPickupReleasePoint: RobotPickupReleasePoint,
  CallPolygon: CallPolygon,
};
