// Auto-generated. Do not edit!

// (in-package jsk_network_tools.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class OCS2FC {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.joint_angles = null;
      this.start_impedance = null;
      this.stop = null;
    }
    else {
      if (initObj.hasOwnProperty('joint_angles')) {
        this.joint_angles = initObj.joint_angles
      }
      else {
        this.joint_angles = new Array(32).fill(0);
      }
      if (initObj.hasOwnProperty('start_impedance')) {
        this.start_impedance = initObj.start_impedance
      }
      else {
        this.start_impedance = false;
      }
      if (initObj.hasOwnProperty('stop')) {
        this.stop = initObj.stop
      }
      else {
        this.stop = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type OCS2FC
    // Check that the constant length array field [joint_angles] has the right length
    if (obj.joint_angles.length !== 32) {
      throw new Error('Unable to serialize array field joint_angles - length must be 32')
    }
    // Serialize message field [joint_angles]
    bufferOffset = _arraySerializer.uint8(obj.joint_angles, buffer, bufferOffset, 32);
    // Serialize message field [start_impedance]
    bufferOffset = _serializer.bool(obj.start_impedance, buffer, bufferOffset);
    // Serialize message field [stop]
    bufferOffset = _serializer.bool(obj.stop, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type OCS2FC
    let len;
    let data = new OCS2FC(null);
    // Deserialize message field [joint_angles]
    data.joint_angles = _arrayDeserializer.uint8(buffer, bufferOffset, 32)
    // Deserialize message field [start_impedance]
    data.start_impedance = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [stop]
    data.stop = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 34;
  }

  static datatype() {
    // Returns string type for a message object
    return 'jsk_network_tools/OCS2FC';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '036058ee69589b4817d296161ea7f432';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # A message from OSC to FC.
    # There is are several limitations
    # 1. no nested fields is allowed.
    # 2. no variable length array is allowed.
    # 3. string is not supported.
    # 4. duration and time are not supported.
    
    uint8[32] joint_angles
    bool start_impedance
    bool stop
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new OCS2FC(null);
    if (msg.joint_angles !== undefined) {
      resolved.joint_angles = msg.joint_angles;
    }
    else {
      resolved.joint_angles = new Array(32).fill(0)
    }

    if (msg.start_impedance !== undefined) {
      resolved.start_impedance = msg.start_impedance;
    }
    else {
      resolved.start_impedance = false
    }

    if (msg.stop !== undefined) {
      resolved.stop = msg.stop;
    }
    else {
      resolved.stop = false
    }

    return resolved;
    }
};

module.exports = OCS2FC;
