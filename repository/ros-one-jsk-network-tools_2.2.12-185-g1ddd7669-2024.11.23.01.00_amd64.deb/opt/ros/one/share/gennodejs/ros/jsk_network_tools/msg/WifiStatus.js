// Auto-generated. Do not edit!

// (in-package jsk_network_tools.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class WifiStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.interface = null;
      this.enabled = null;
      this.connected = null;
      this.ssid = null;
      this.frequency = null;
      this.access_point = null;
      this.bitrate = null;
      this.tx_power = null;
      this.link_quality = null;
      this.signal_level = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('interface')) {
        this.interface = initObj.interface
      }
      else {
        this.interface = '';
      }
      if (initObj.hasOwnProperty('enabled')) {
        this.enabled = initObj.enabled
      }
      else {
        this.enabled = false;
      }
      if (initObj.hasOwnProperty('connected')) {
        this.connected = initObj.connected
      }
      else {
        this.connected = false;
      }
      if (initObj.hasOwnProperty('ssid')) {
        this.ssid = initObj.ssid
      }
      else {
        this.ssid = '';
      }
      if (initObj.hasOwnProperty('frequency')) {
        this.frequency = initObj.frequency
      }
      else {
        this.frequency = 0.0;
      }
      if (initObj.hasOwnProperty('access_point')) {
        this.access_point = initObj.access_point
      }
      else {
        this.access_point = '';
      }
      if (initObj.hasOwnProperty('bitrate')) {
        this.bitrate = initObj.bitrate
      }
      else {
        this.bitrate = 0.0;
      }
      if (initObj.hasOwnProperty('tx_power')) {
        this.tx_power = initObj.tx_power
      }
      else {
        this.tx_power = 0;
      }
      if (initObj.hasOwnProperty('link_quality')) {
        this.link_quality = initObj.link_quality
      }
      else {
        this.link_quality = 0.0;
      }
      if (initObj.hasOwnProperty('signal_level')) {
        this.signal_level = initObj.signal_level
      }
      else {
        this.signal_level = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type WifiStatus
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [interface]
    bufferOffset = _serializer.string(obj.interface, buffer, bufferOffset);
    // Serialize message field [enabled]
    bufferOffset = _serializer.bool(obj.enabled, buffer, bufferOffset);
    // Serialize message field [connected]
    bufferOffset = _serializer.bool(obj.connected, buffer, bufferOffset);
    // Serialize message field [ssid]
    bufferOffset = _serializer.string(obj.ssid, buffer, bufferOffset);
    // Serialize message field [frequency]
    bufferOffset = _serializer.float32(obj.frequency, buffer, bufferOffset);
    // Serialize message field [access_point]
    bufferOffset = _serializer.string(obj.access_point, buffer, bufferOffset);
    // Serialize message field [bitrate]
    bufferOffset = _serializer.float32(obj.bitrate, buffer, bufferOffset);
    // Serialize message field [tx_power]
    bufferOffset = _serializer.int16(obj.tx_power, buffer, bufferOffset);
    // Serialize message field [link_quality]
    bufferOffset = _serializer.float32(obj.link_quality, buffer, bufferOffset);
    // Serialize message field [signal_level]
    bufferOffset = _serializer.int16(obj.signal_level, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type WifiStatus
    let len;
    let data = new WifiStatus(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [interface]
    data.interface = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [enabled]
    data.enabled = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [connected]
    data.connected = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [ssid]
    data.ssid = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [frequency]
    data.frequency = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [access_point]
    data.access_point = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [bitrate]
    data.bitrate = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [tx_power]
    data.tx_power = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [link_quality]
    data.link_quality = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [signal_level]
    data.signal_level = _deserializer.int16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.interface);
    length += _getByteLength(object.ssid);
    length += _getByteLength(object.access_point);
    return length + 30;
  }

  static datatype() {
    // Returns string type for a message object
    return 'jsk_network_tools/WifiStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '94da4b64008d69473c62c62019a8c0f6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    string interface
    bool enabled
    bool connected
    string ssid
    float32 frequency # GHz
    string access_point
    float32 bitrate # Mb/s
    int16 tx_power # dBm
    float32 link_quality
    int16 signal_level # dBm
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new WifiStatus(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.interface !== undefined) {
      resolved.interface = msg.interface;
    }
    else {
      resolved.interface = ''
    }

    if (msg.enabled !== undefined) {
      resolved.enabled = msg.enabled;
    }
    else {
      resolved.enabled = false
    }

    if (msg.connected !== undefined) {
      resolved.connected = msg.connected;
    }
    else {
      resolved.connected = false
    }

    if (msg.ssid !== undefined) {
      resolved.ssid = msg.ssid;
    }
    else {
      resolved.ssid = ''
    }

    if (msg.frequency !== undefined) {
      resolved.frequency = msg.frequency;
    }
    else {
      resolved.frequency = 0.0
    }

    if (msg.access_point !== undefined) {
      resolved.access_point = msg.access_point;
    }
    else {
      resolved.access_point = ''
    }

    if (msg.bitrate !== undefined) {
      resolved.bitrate = msg.bitrate;
    }
    else {
      resolved.bitrate = 0.0
    }

    if (msg.tx_power !== undefined) {
      resolved.tx_power = msg.tx_power;
    }
    else {
      resolved.tx_power = 0
    }

    if (msg.link_quality !== undefined) {
      resolved.link_quality = msg.link_quality;
    }
    else {
      resolved.link_quality = 0.0
    }

    if (msg.signal_level !== undefined) {
      resolved.signal_level = msg.signal_level;
    }
    else {
      resolved.signal_level = 0
    }

    return resolved;
    }
};

module.exports = WifiStatus;
