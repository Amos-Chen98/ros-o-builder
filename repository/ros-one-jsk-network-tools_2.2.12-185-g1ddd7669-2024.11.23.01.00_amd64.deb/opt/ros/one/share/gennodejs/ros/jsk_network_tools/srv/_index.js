
"use strict";

let SetSendRate = require('./SetSendRate.js')

module.exports = {
  SetSendRate: SetSendRate,
};
