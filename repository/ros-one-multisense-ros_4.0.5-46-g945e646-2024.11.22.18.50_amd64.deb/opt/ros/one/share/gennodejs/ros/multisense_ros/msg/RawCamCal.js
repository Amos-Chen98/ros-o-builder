// Auto-generated. Do not edit!

// (in-package multisense_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class RawCamCal {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.left_M = null;
      this.left_D = null;
      this.left_R = null;
      this.left_P = null;
      this.right_M = null;
      this.right_D = null;
      this.right_R = null;
      this.right_P = null;
    }
    else {
      if (initObj.hasOwnProperty('left_M')) {
        this.left_M = initObj.left_M
      }
      else {
        this.left_M = new Array(9).fill(0);
      }
      if (initObj.hasOwnProperty('left_D')) {
        this.left_D = initObj.left_D
      }
      else {
        this.left_D = new Array(8).fill(0);
      }
      if (initObj.hasOwnProperty('left_R')) {
        this.left_R = initObj.left_R
      }
      else {
        this.left_R = new Array(9).fill(0);
      }
      if (initObj.hasOwnProperty('left_P')) {
        this.left_P = initObj.left_P
      }
      else {
        this.left_P = new Array(12).fill(0);
      }
      if (initObj.hasOwnProperty('right_M')) {
        this.right_M = initObj.right_M
      }
      else {
        this.right_M = new Array(9).fill(0);
      }
      if (initObj.hasOwnProperty('right_D')) {
        this.right_D = initObj.right_D
      }
      else {
        this.right_D = new Array(8).fill(0);
      }
      if (initObj.hasOwnProperty('right_R')) {
        this.right_R = initObj.right_R
      }
      else {
        this.right_R = new Array(9).fill(0);
      }
      if (initObj.hasOwnProperty('right_P')) {
        this.right_P = initObj.right_P
      }
      else {
        this.right_P = new Array(12).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RawCamCal
    // Check that the constant length array field [left_M] has the right length
    if (obj.left_M.length !== 9) {
      throw new Error('Unable to serialize array field left_M - length must be 9')
    }
    // Serialize message field [left_M]
    bufferOffset = _arraySerializer.float32(obj.left_M, buffer, bufferOffset, 9);
    // Check that the constant length array field [left_D] has the right length
    if (obj.left_D.length !== 8) {
      throw new Error('Unable to serialize array field left_D - length must be 8')
    }
    // Serialize message field [left_D]
    bufferOffset = _arraySerializer.float32(obj.left_D, buffer, bufferOffset, 8);
    // Check that the constant length array field [left_R] has the right length
    if (obj.left_R.length !== 9) {
      throw new Error('Unable to serialize array field left_R - length must be 9')
    }
    // Serialize message field [left_R]
    bufferOffset = _arraySerializer.float32(obj.left_R, buffer, bufferOffset, 9);
    // Check that the constant length array field [left_P] has the right length
    if (obj.left_P.length !== 12) {
      throw new Error('Unable to serialize array field left_P - length must be 12')
    }
    // Serialize message field [left_P]
    bufferOffset = _arraySerializer.float32(obj.left_P, buffer, bufferOffset, 12);
    // Check that the constant length array field [right_M] has the right length
    if (obj.right_M.length !== 9) {
      throw new Error('Unable to serialize array field right_M - length must be 9')
    }
    // Serialize message field [right_M]
    bufferOffset = _arraySerializer.float32(obj.right_M, buffer, bufferOffset, 9);
    // Check that the constant length array field [right_D] has the right length
    if (obj.right_D.length !== 8) {
      throw new Error('Unable to serialize array field right_D - length must be 8')
    }
    // Serialize message field [right_D]
    bufferOffset = _arraySerializer.float32(obj.right_D, buffer, bufferOffset, 8);
    // Check that the constant length array field [right_R] has the right length
    if (obj.right_R.length !== 9) {
      throw new Error('Unable to serialize array field right_R - length must be 9')
    }
    // Serialize message field [right_R]
    bufferOffset = _arraySerializer.float32(obj.right_R, buffer, bufferOffset, 9);
    // Check that the constant length array field [right_P] has the right length
    if (obj.right_P.length !== 12) {
      throw new Error('Unable to serialize array field right_P - length must be 12')
    }
    // Serialize message field [right_P]
    bufferOffset = _arraySerializer.float32(obj.right_P, buffer, bufferOffset, 12);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RawCamCal
    let len;
    let data = new RawCamCal(null);
    // Deserialize message field [left_M]
    data.left_M = _arrayDeserializer.float32(buffer, bufferOffset, 9)
    // Deserialize message field [left_D]
    data.left_D = _arrayDeserializer.float32(buffer, bufferOffset, 8)
    // Deserialize message field [left_R]
    data.left_R = _arrayDeserializer.float32(buffer, bufferOffset, 9)
    // Deserialize message field [left_P]
    data.left_P = _arrayDeserializer.float32(buffer, bufferOffset, 12)
    // Deserialize message field [right_M]
    data.right_M = _arrayDeserializer.float32(buffer, bufferOffset, 9)
    // Deserialize message field [right_D]
    data.right_D = _arrayDeserializer.float32(buffer, bufferOffset, 8)
    // Deserialize message field [right_R]
    data.right_R = _arrayDeserializer.float32(buffer, bufferOffset, 9)
    // Deserialize message field [right_P]
    data.right_P = _arrayDeserializer.float32(buffer, bufferOffset, 12)
    return data;
  }

  static getMessageSize(object) {
    return 304;
  }

  static datatype() {
    // Returns string type for a message object
    return 'multisense_ros/RawCamCal';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1b8c86de8eb033489e8e49fb5532702e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32[9]  left_M
    float32[8]  left_D
    float32[9]  left_R
    float32[12] left_P
    float32[9]  right_M
    float32[8]  right_D
    float32[9]  right_R
    float32[12] right_P
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RawCamCal(null);
    if (msg.left_M !== undefined) {
      resolved.left_M = msg.left_M;
    }
    else {
      resolved.left_M = new Array(9).fill(0)
    }

    if (msg.left_D !== undefined) {
      resolved.left_D = msg.left_D;
    }
    else {
      resolved.left_D = new Array(8).fill(0)
    }

    if (msg.left_R !== undefined) {
      resolved.left_R = msg.left_R;
    }
    else {
      resolved.left_R = new Array(9).fill(0)
    }

    if (msg.left_P !== undefined) {
      resolved.left_P = msg.left_P;
    }
    else {
      resolved.left_P = new Array(12).fill(0)
    }

    if (msg.right_M !== undefined) {
      resolved.right_M = msg.right_M;
    }
    else {
      resolved.right_M = new Array(9).fill(0)
    }

    if (msg.right_D !== undefined) {
      resolved.right_D = msg.right_D;
    }
    else {
      resolved.right_D = new Array(8).fill(0)
    }

    if (msg.right_R !== undefined) {
      resolved.right_R = msg.right_R;
    }
    else {
      resolved.right_R = new Array(9).fill(0)
    }

    if (msg.right_P !== undefined) {
      resolved.right_P = msg.right_P;
    }
    else {
      resolved.right_P = new Array(12).fill(0)
    }

    return resolved;
    }
};

module.exports = RawCamCal;
