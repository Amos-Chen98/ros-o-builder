// Auto-generated. Do not edit!

// (in-package multisense_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class DeviceInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.deviceName = null;
      this.buildDate = null;
      this.serialNumber = null;
      this.deviceRevision = null;
      this.numberOfPcbs = null;
      this.pcbSerialNumbers = null;
      this.pcbNames = null;
      this.imagerName = null;
      this.imagerType = null;
      this.imagerWidth = null;
      this.imagerHeight = null;
      this.lensName = null;
      this.lensType = null;
      this.nominalBaseline = null;
      this.nominalFocalLength = null;
      this.nominalRelativeAperture = null;
      this.lightingType = null;
      this.numberOfLights = null;
      this.laserName = null;
      this.laserType = null;
      this.motorName = null;
      this.motorType = null;
      this.motorGearReduction = null;
      this.apiVersion = null;
      this.firmwareBuildDate = null;
      this.firmwareVersion = null;
      this.bitstreamVersion = null;
      this.bitstreamMagic = null;
      this.fpgaDna = null;
    }
    else {
      if (initObj.hasOwnProperty('deviceName')) {
        this.deviceName = initObj.deviceName
      }
      else {
        this.deviceName = '';
      }
      if (initObj.hasOwnProperty('buildDate')) {
        this.buildDate = initObj.buildDate
      }
      else {
        this.buildDate = '';
      }
      if (initObj.hasOwnProperty('serialNumber')) {
        this.serialNumber = initObj.serialNumber
      }
      else {
        this.serialNumber = '';
      }
      if (initObj.hasOwnProperty('deviceRevision')) {
        this.deviceRevision = initObj.deviceRevision
      }
      else {
        this.deviceRevision = 0;
      }
      if (initObj.hasOwnProperty('numberOfPcbs')) {
        this.numberOfPcbs = initObj.numberOfPcbs
      }
      else {
        this.numberOfPcbs = 0;
      }
      if (initObj.hasOwnProperty('pcbSerialNumbers')) {
        this.pcbSerialNumbers = initObj.pcbSerialNumbers
      }
      else {
        this.pcbSerialNumbers = [];
      }
      if (initObj.hasOwnProperty('pcbNames')) {
        this.pcbNames = initObj.pcbNames
      }
      else {
        this.pcbNames = [];
      }
      if (initObj.hasOwnProperty('imagerName')) {
        this.imagerName = initObj.imagerName
      }
      else {
        this.imagerName = '';
      }
      if (initObj.hasOwnProperty('imagerType')) {
        this.imagerType = initObj.imagerType
      }
      else {
        this.imagerType = 0;
      }
      if (initObj.hasOwnProperty('imagerWidth')) {
        this.imagerWidth = initObj.imagerWidth
      }
      else {
        this.imagerWidth = 0;
      }
      if (initObj.hasOwnProperty('imagerHeight')) {
        this.imagerHeight = initObj.imagerHeight
      }
      else {
        this.imagerHeight = 0;
      }
      if (initObj.hasOwnProperty('lensName')) {
        this.lensName = initObj.lensName
      }
      else {
        this.lensName = '';
      }
      if (initObj.hasOwnProperty('lensType')) {
        this.lensType = initObj.lensType
      }
      else {
        this.lensType = 0;
      }
      if (initObj.hasOwnProperty('nominalBaseline')) {
        this.nominalBaseline = initObj.nominalBaseline
      }
      else {
        this.nominalBaseline = 0.0;
      }
      if (initObj.hasOwnProperty('nominalFocalLength')) {
        this.nominalFocalLength = initObj.nominalFocalLength
      }
      else {
        this.nominalFocalLength = 0.0;
      }
      if (initObj.hasOwnProperty('nominalRelativeAperture')) {
        this.nominalRelativeAperture = initObj.nominalRelativeAperture
      }
      else {
        this.nominalRelativeAperture = 0.0;
      }
      if (initObj.hasOwnProperty('lightingType')) {
        this.lightingType = initObj.lightingType
      }
      else {
        this.lightingType = 0;
      }
      if (initObj.hasOwnProperty('numberOfLights')) {
        this.numberOfLights = initObj.numberOfLights
      }
      else {
        this.numberOfLights = 0;
      }
      if (initObj.hasOwnProperty('laserName')) {
        this.laserName = initObj.laserName
      }
      else {
        this.laserName = '';
      }
      if (initObj.hasOwnProperty('laserType')) {
        this.laserType = initObj.laserType
      }
      else {
        this.laserType = 0;
      }
      if (initObj.hasOwnProperty('motorName')) {
        this.motorName = initObj.motorName
      }
      else {
        this.motorName = '';
      }
      if (initObj.hasOwnProperty('motorType')) {
        this.motorType = initObj.motorType
      }
      else {
        this.motorType = 0;
      }
      if (initObj.hasOwnProperty('motorGearReduction')) {
        this.motorGearReduction = initObj.motorGearReduction
      }
      else {
        this.motorGearReduction = 0.0;
      }
      if (initObj.hasOwnProperty('apiVersion')) {
        this.apiVersion = initObj.apiVersion
      }
      else {
        this.apiVersion = 0;
      }
      if (initObj.hasOwnProperty('firmwareBuildDate')) {
        this.firmwareBuildDate = initObj.firmwareBuildDate
      }
      else {
        this.firmwareBuildDate = '';
      }
      if (initObj.hasOwnProperty('firmwareVersion')) {
        this.firmwareVersion = initObj.firmwareVersion
      }
      else {
        this.firmwareVersion = 0;
      }
      if (initObj.hasOwnProperty('bitstreamVersion')) {
        this.bitstreamVersion = initObj.bitstreamVersion
      }
      else {
        this.bitstreamVersion = 0;
      }
      if (initObj.hasOwnProperty('bitstreamMagic')) {
        this.bitstreamMagic = initObj.bitstreamMagic
      }
      else {
        this.bitstreamMagic = 0;
      }
      if (initObj.hasOwnProperty('fpgaDna')) {
        this.fpgaDna = initObj.fpgaDna
      }
      else {
        this.fpgaDna = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DeviceInfo
    // Serialize message field [deviceName]
    bufferOffset = _serializer.string(obj.deviceName, buffer, bufferOffset);
    // Serialize message field [buildDate]
    bufferOffset = _serializer.string(obj.buildDate, buffer, bufferOffset);
    // Serialize message field [serialNumber]
    bufferOffset = _serializer.string(obj.serialNumber, buffer, bufferOffset);
    // Serialize message field [deviceRevision]
    bufferOffset = _serializer.uint32(obj.deviceRevision, buffer, bufferOffset);
    // Serialize message field [numberOfPcbs]
    bufferOffset = _serializer.uint32(obj.numberOfPcbs, buffer, bufferOffset);
    // Serialize message field [pcbSerialNumbers]
    bufferOffset = _arraySerializer.uint32(obj.pcbSerialNumbers, buffer, bufferOffset, null);
    // Serialize message field [pcbNames]
    bufferOffset = _arraySerializer.string(obj.pcbNames, buffer, bufferOffset, null);
    // Serialize message field [imagerName]
    bufferOffset = _serializer.string(obj.imagerName, buffer, bufferOffset);
    // Serialize message field [imagerType]
    bufferOffset = _serializer.uint32(obj.imagerType, buffer, bufferOffset);
    // Serialize message field [imagerWidth]
    bufferOffset = _serializer.uint32(obj.imagerWidth, buffer, bufferOffset);
    // Serialize message field [imagerHeight]
    bufferOffset = _serializer.uint32(obj.imagerHeight, buffer, bufferOffset);
    // Serialize message field [lensName]
    bufferOffset = _serializer.string(obj.lensName, buffer, bufferOffset);
    // Serialize message field [lensType]
    bufferOffset = _serializer.uint32(obj.lensType, buffer, bufferOffset);
    // Serialize message field [nominalBaseline]
    bufferOffset = _serializer.float32(obj.nominalBaseline, buffer, bufferOffset);
    // Serialize message field [nominalFocalLength]
    bufferOffset = _serializer.float32(obj.nominalFocalLength, buffer, bufferOffset);
    // Serialize message field [nominalRelativeAperture]
    bufferOffset = _serializer.float32(obj.nominalRelativeAperture, buffer, bufferOffset);
    // Serialize message field [lightingType]
    bufferOffset = _serializer.uint32(obj.lightingType, buffer, bufferOffset);
    // Serialize message field [numberOfLights]
    bufferOffset = _serializer.uint32(obj.numberOfLights, buffer, bufferOffset);
    // Serialize message field [laserName]
    bufferOffset = _serializer.string(obj.laserName, buffer, bufferOffset);
    // Serialize message field [laserType]
    bufferOffset = _serializer.uint32(obj.laserType, buffer, bufferOffset);
    // Serialize message field [motorName]
    bufferOffset = _serializer.string(obj.motorName, buffer, bufferOffset);
    // Serialize message field [motorType]
    bufferOffset = _serializer.uint32(obj.motorType, buffer, bufferOffset);
    // Serialize message field [motorGearReduction]
    bufferOffset = _serializer.float32(obj.motorGearReduction, buffer, bufferOffset);
    // Serialize message field [apiVersion]
    bufferOffset = _serializer.uint16(obj.apiVersion, buffer, bufferOffset);
    // Serialize message field [firmwareBuildDate]
    bufferOffset = _serializer.string(obj.firmwareBuildDate, buffer, bufferOffset);
    // Serialize message field [firmwareVersion]
    bufferOffset = _serializer.uint16(obj.firmwareVersion, buffer, bufferOffset);
    // Serialize message field [bitstreamVersion]
    bufferOffset = _serializer.uint64(obj.bitstreamVersion, buffer, bufferOffset);
    // Serialize message field [bitstreamMagic]
    bufferOffset = _serializer.uint64(obj.bitstreamMagic, buffer, bufferOffset);
    // Serialize message field [fpgaDna]
    bufferOffset = _serializer.uint64(obj.fpgaDna, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DeviceInfo
    let len;
    let data = new DeviceInfo(null);
    // Deserialize message field [deviceName]
    data.deviceName = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [buildDate]
    data.buildDate = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [serialNumber]
    data.serialNumber = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [deviceRevision]
    data.deviceRevision = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [numberOfPcbs]
    data.numberOfPcbs = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [pcbSerialNumbers]
    data.pcbSerialNumbers = _arrayDeserializer.uint32(buffer, bufferOffset, null)
    // Deserialize message field [pcbNames]
    data.pcbNames = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [imagerName]
    data.imagerName = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [imagerType]
    data.imagerType = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [imagerWidth]
    data.imagerWidth = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [imagerHeight]
    data.imagerHeight = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [lensName]
    data.lensName = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [lensType]
    data.lensType = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [nominalBaseline]
    data.nominalBaseline = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [nominalFocalLength]
    data.nominalFocalLength = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [nominalRelativeAperture]
    data.nominalRelativeAperture = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [lightingType]
    data.lightingType = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [numberOfLights]
    data.numberOfLights = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [laserName]
    data.laserName = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [laserType]
    data.laserType = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [motorName]
    data.motorName = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [motorType]
    data.motorType = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [motorGearReduction]
    data.motorGearReduction = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [apiVersion]
    data.apiVersion = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [firmwareBuildDate]
    data.firmwareBuildDate = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [firmwareVersion]
    data.firmwareVersion = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [bitstreamVersion]
    data.bitstreamVersion = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [bitstreamMagic]
    data.bitstreamMagic = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [fpgaDna]
    data.fpgaDna = _deserializer.uint64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.deviceName);
    length += _getByteLength(object.buildDate);
    length += _getByteLength(object.serialNumber);
    length += 4 * object.pcbSerialNumbers.length;
    object.pcbNames.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += _getByteLength(object.imagerName);
    length += _getByteLength(object.lensName);
    length += _getByteLength(object.laserName);
    length += _getByteLength(object.motorName);
    length += _getByteLength(object.firmwareBuildDate);
    return length + 124;
  }

  static datatype() {
    // Returns string type for a message object
    return 'multisense_ros/DeviceInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '28a7dd5512949a6e04abf089c1079b8d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string deviceName
    string buildDate
    string serialNumber
    uint32 deviceRevision
    
    uint32    numberOfPcbs
    uint32[] pcbSerialNumbers
    string[] pcbNames
    
    string imagerName
    uint32 imagerType
    uint32 imagerWidth
    uint32 imagerHeight
    
    string lensName
    uint32 lensType
    float32 nominalBaseline
    float32 nominalFocalLength
    float32 nominalRelativeAperture
    
    uint32 lightingType
    uint32 numberOfLights
    
    string laserName
    uint32 laserType
    
    string motorName
    uint32 motorType
    float32 motorGearReduction
    
    uint16 apiVersion
    string firmwareBuildDate
    uint16 firmwareVersion
    
    uint64 bitstreamVersion
    uint64 bitstreamMagic
    uint64 fpgaDna
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DeviceInfo(null);
    if (msg.deviceName !== undefined) {
      resolved.deviceName = msg.deviceName;
    }
    else {
      resolved.deviceName = ''
    }

    if (msg.buildDate !== undefined) {
      resolved.buildDate = msg.buildDate;
    }
    else {
      resolved.buildDate = ''
    }

    if (msg.serialNumber !== undefined) {
      resolved.serialNumber = msg.serialNumber;
    }
    else {
      resolved.serialNumber = ''
    }

    if (msg.deviceRevision !== undefined) {
      resolved.deviceRevision = msg.deviceRevision;
    }
    else {
      resolved.deviceRevision = 0
    }

    if (msg.numberOfPcbs !== undefined) {
      resolved.numberOfPcbs = msg.numberOfPcbs;
    }
    else {
      resolved.numberOfPcbs = 0
    }

    if (msg.pcbSerialNumbers !== undefined) {
      resolved.pcbSerialNumbers = msg.pcbSerialNumbers;
    }
    else {
      resolved.pcbSerialNumbers = []
    }

    if (msg.pcbNames !== undefined) {
      resolved.pcbNames = msg.pcbNames;
    }
    else {
      resolved.pcbNames = []
    }

    if (msg.imagerName !== undefined) {
      resolved.imagerName = msg.imagerName;
    }
    else {
      resolved.imagerName = ''
    }

    if (msg.imagerType !== undefined) {
      resolved.imagerType = msg.imagerType;
    }
    else {
      resolved.imagerType = 0
    }

    if (msg.imagerWidth !== undefined) {
      resolved.imagerWidth = msg.imagerWidth;
    }
    else {
      resolved.imagerWidth = 0
    }

    if (msg.imagerHeight !== undefined) {
      resolved.imagerHeight = msg.imagerHeight;
    }
    else {
      resolved.imagerHeight = 0
    }

    if (msg.lensName !== undefined) {
      resolved.lensName = msg.lensName;
    }
    else {
      resolved.lensName = ''
    }

    if (msg.lensType !== undefined) {
      resolved.lensType = msg.lensType;
    }
    else {
      resolved.lensType = 0
    }

    if (msg.nominalBaseline !== undefined) {
      resolved.nominalBaseline = msg.nominalBaseline;
    }
    else {
      resolved.nominalBaseline = 0.0
    }

    if (msg.nominalFocalLength !== undefined) {
      resolved.nominalFocalLength = msg.nominalFocalLength;
    }
    else {
      resolved.nominalFocalLength = 0.0
    }

    if (msg.nominalRelativeAperture !== undefined) {
      resolved.nominalRelativeAperture = msg.nominalRelativeAperture;
    }
    else {
      resolved.nominalRelativeAperture = 0.0
    }

    if (msg.lightingType !== undefined) {
      resolved.lightingType = msg.lightingType;
    }
    else {
      resolved.lightingType = 0
    }

    if (msg.numberOfLights !== undefined) {
      resolved.numberOfLights = msg.numberOfLights;
    }
    else {
      resolved.numberOfLights = 0
    }

    if (msg.laserName !== undefined) {
      resolved.laserName = msg.laserName;
    }
    else {
      resolved.laserName = ''
    }

    if (msg.laserType !== undefined) {
      resolved.laserType = msg.laserType;
    }
    else {
      resolved.laserType = 0
    }

    if (msg.motorName !== undefined) {
      resolved.motorName = msg.motorName;
    }
    else {
      resolved.motorName = ''
    }

    if (msg.motorType !== undefined) {
      resolved.motorType = msg.motorType;
    }
    else {
      resolved.motorType = 0
    }

    if (msg.motorGearReduction !== undefined) {
      resolved.motorGearReduction = msg.motorGearReduction;
    }
    else {
      resolved.motorGearReduction = 0.0
    }

    if (msg.apiVersion !== undefined) {
      resolved.apiVersion = msg.apiVersion;
    }
    else {
      resolved.apiVersion = 0
    }

    if (msg.firmwareBuildDate !== undefined) {
      resolved.firmwareBuildDate = msg.firmwareBuildDate;
    }
    else {
      resolved.firmwareBuildDate = ''
    }

    if (msg.firmwareVersion !== undefined) {
      resolved.firmwareVersion = msg.firmwareVersion;
    }
    else {
      resolved.firmwareVersion = 0
    }

    if (msg.bitstreamVersion !== undefined) {
      resolved.bitstreamVersion = msg.bitstreamVersion;
    }
    else {
      resolved.bitstreamVersion = 0
    }

    if (msg.bitstreamMagic !== undefined) {
      resolved.bitstreamMagic = msg.bitstreamMagic;
    }
    else {
      resolved.bitstreamMagic = 0
    }

    if (msg.fpgaDna !== undefined) {
      resolved.fpgaDna = msg.fpgaDna;
    }
    else {
      resolved.fpgaDna = 0
    }

    return resolved;
    }
};

module.exports = DeviceInfo;
