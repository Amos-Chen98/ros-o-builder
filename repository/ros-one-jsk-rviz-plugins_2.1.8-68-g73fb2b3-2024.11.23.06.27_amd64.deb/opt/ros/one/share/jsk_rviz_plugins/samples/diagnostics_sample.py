#/usr/bin/env pytnon

import rospy
import diagnostics_msgs
import diagnostics_updater

if __name__ == "__main__":
    rospy.init("diagnostics_sample")
    
