
"use strict";

let TypeDef = require('./TypeDef.js');

module.exports = {
  TypeDef: TypeDef,
};
