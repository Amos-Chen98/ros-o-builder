
"use strict";

let TestActionFeedback = require('./TestActionFeedback.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TestActionGoal = require('./TestActionGoal.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestRequestAction = require('./TestRequestAction.js');
let TestRequestResult = require('./TestRequestResult.js');
let TestGoal = require('./TestGoal.js');
let TestAction = require('./TestAction.js');
let TestResult = require('./TestResult.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TestActionResult = require('./TestActionResult.js');
let TestFeedback = require('./TestFeedback.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');

module.exports = {
  TestActionFeedback: TestActionFeedback,
  TestRequestActionGoal: TestRequestActionGoal,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TestActionGoal: TestActionGoal,
  TwoIntsResult: TwoIntsResult,
  TwoIntsFeedback: TwoIntsFeedback,
  TwoIntsGoal: TwoIntsGoal,
  TestRequestFeedback: TestRequestFeedback,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestRequestAction: TestRequestAction,
  TestRequestResult: TestRequestResult,
  TestGoal: TestGoal,
  TestAction: TestAction,
  TestResult: TestResult,
  TestRequestGoal: TestRequestGoal,
  TestActionResult: TestActionResult,
  TestFeedback: TestFeedback,
  TwoIntsAction: TwoIntsAction,
  TestRequestActionResult: TestRequestActionResult,
  TwoIntsActionResult: TwoIntsActionResult,
};
