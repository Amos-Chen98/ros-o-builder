
"use strict";

let FaceRecognitionTrain = require('./FaceRecognitionTrain.js')

module.exports = {
  FaceRecognitionTrain: FaceRecognitionTrain,
};
