#if !EIGEN_VERSION_AT_LEAST(3, 3, 3)
typedef Scalar value_type;
#endif
