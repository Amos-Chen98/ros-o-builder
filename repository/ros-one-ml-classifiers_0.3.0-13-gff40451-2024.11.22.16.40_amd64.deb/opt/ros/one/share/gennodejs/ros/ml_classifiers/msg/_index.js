
"use strict";

let ClassDataPoint = require('./ClassDataPoint.js');

module.exports = {
  ClassDataPoint: ClassDataPoint,
};
