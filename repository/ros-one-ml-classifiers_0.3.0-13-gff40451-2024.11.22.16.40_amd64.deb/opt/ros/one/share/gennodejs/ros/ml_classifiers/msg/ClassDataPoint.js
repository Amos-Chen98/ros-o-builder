// Auto-generated. Do not edit!

// (in-package ml_classifiers.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ClassDataPoint {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.target_class = null;
      this.point = null;
    }
    else {
      if (initObj.hasOwnProperty('target_class')) {
        this.target_class = initObj.target_class
      }
      else {
        this.target_class = '';
      }
      if (initObj.hasOwnProperty('point')) {
        this.point = initObj.point
      }
      else {
        this.point = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ClassDataPoint
    // Serialize message field [target_class]
    bufferOffset = _serializer.string(obj.target_class, buffer, bufferOffset);
    // Serialize message field [point]
    bufferOffset = _arraySerializer.float64(obj.point, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ClassDataPoint
    let len;
    let data = new ClassDataPoint(null);
    // Deserialize message field [target_class]
    data.target_class = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [point]
    data.point = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.target_class);
    length += 8 * object.point.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ml_classifiers/ClassDataPoint';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '46bea2d2ef979a71ef0bfa470e5978ff';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string target_class
    float64[] point
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ClassDataPoint(null);
    if (msg.target_class !== undefined) {
      resolved.target_class = msg.target_class;
    }
    else {
      resolved.target_class = ''
    }

    if (msg.point !== undefined) {
      resolved.point = msg.point;
    }
    else {
      resolved.point = []
    }

    return resolved;
    }
};

module.exports = ClassDataPoint;
