// Auto-generated. Do not edit!

// (in-package ml_classifiers.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ClassDataPoint = require('../msg/ClassDataPoint.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class ClassifyDataRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.identifier = null;
      this.data = null;
    }
    else {
      if (initObj.hasOwnProperty('identifier')) {
        this.identifier = initObj.identifier
      }
      else {
        this.identifier = '';
      }
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ClassifyDataRequest
    // Serialize message field [identifier]
    bufferOffset = _serializer.string(obj.identifier, buffer, bufferOffset);
    // Serialize message field [data]
    // Serialize the length for message field [data]
    bufferOffset = _serializer.uint32(obj.data.length, buffer, bufferOffset);
    obj.data.forEach((val) => {
      bufferOffset = ClassDataPoint.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ClassifyDataRequest
    let len;
    let data = new ClassifyDataRequest(null);
    // Deserialize message field [identifier]
    data.identifier = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [data]
    // Deserialize array length for message field [data]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.data = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.data[i] = ClassDataPoint.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.identifier);
    object.data.forEach((val) => {
      length += ClassDataPoint.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ml_classifiers/ClassifyDataRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '572733f6e77cd60bddc5c0b72307999c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string identifier
    ClassDataPoint[] data
    
    ================================================================================
    MSG: ml_classifiers/ClassDataPoint
    string target_class
    float64[] point
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ClassifyDataRequest(null);
    if (msg.identifier !== undefined) {
      resolved.identifier = msg.identifier;
    }
    else {
      resolved.identifier = ''
    }

    if (msg.data !== undefined) {
      resolved.data = new Array(msg.data.length);
      for (let i = 0; i < resolved.data.length; ++i) {
        resolved.data[i] = ClassDataPoint.Resolve(msg.data[i]);
      }
    }
    else {
      resolved.data = []
    }

    return resolved;
    }
};

class ClassifyDataResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.classifications = null;
    }
    else {
      if (initObj.hasOwnProperty('classifications')) {
        this.classifications = initObj.classifications
      }
      else {
        this.classifications = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ClassifyDataResponse
    // Serialize message field [classifications]
    bufferOffset = _arraySerializer.string(obj.classifications, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ClassifyDataResponse
    let len;
    let data = new ClassifyDataResponse(null);
    // Deserialize message field [classifications]
    data.classifications = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.classifications.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ml_classifiers/ClassifyDataResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5ce145dc8157b011850524b4b0ffd0b7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string[] classifications
    
    
    
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ClassifyDataResponse(null);
    if (msg.classifications !== undefined) {
      resolved.classifications = msg.classifications;
    }
    else {
      resolved.classifications = []
    }

    return resolved;
    }
};

module.exports = {
  Request: ClassifyDataRequest,
  Response: ClassifyDataResponse,
  md5sum() { return '5ee7ec82bea2c231e357662def7bf4a4'; },
  datatype() { return 'ml_classifiers/ClassifyData'; }
};
