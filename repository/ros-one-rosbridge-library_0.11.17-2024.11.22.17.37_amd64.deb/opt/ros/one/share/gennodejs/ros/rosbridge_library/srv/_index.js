
"use strict";

let AddTwoInts = require('./AddTwoInts.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let TestArrayRequest = require('./TestArrayRequest.js')
let TestNestedService = require('./TestNestedService.js')
let TestRequestAndResponse = require('./TestRequestAndResponse.js')
let TestEmpty = require('./TestEmpty.js')
let TestRequestOnly = require('./TestRequestOnly.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let SendBytes = require('./SendBytes.js')
let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')

module.exports = {
  AddTwoInts: AddTwoInts,
  TestResponseOnly: TestResponseOnly,
  TestArrayRequest: TestArrayRequest,
  TestNestedService: TestNestedService,
  TestRequestAndResponse: TestRequestAndResponse,
  TestEmpty: TestEmpty,
  TestRequestOnly: TestRequestOnly,
  TestMultipleRequestFields: TestMultipleRequestFields,
  SendBytes: SendBytes,
  TestMultipleResponseFields: TestMultipleResponseFields,
};
