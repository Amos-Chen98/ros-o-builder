// Auto-generated. Do not edit!

// (in-package switchbot_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class StripLight {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.power = null;
      this.brightness = null;
      this.color_r = null;
      this.color_g = null;
      this.color_b = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('power')) {
        this.power = initObj.power
      }
      else {
        this.power = false;
      }
      if (initObj.hasOwnProperty('brightness')) {
        this.brightness = initObj.brightness
      }
      else {
        this.brightness = 0;
      }
      if (initObj.hasOwnProperty('color_r')) {
        this.color_r = initObj.color_r
      }
      else {
        this.color_r = 0;
      }
      if (initObj.hasOwnProperty('color_g')) {
        this.color_g = initObj.color_g
      }
      else {
        this.color_g = 0;
      }
      if (initObj.hasOwnProperty('color_b')) {
        this.color_b = initObj.color_b
      }
      else {
        this.color_b = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type StripLight
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [power]
    bufferOffset = _serializer.bool(obj.power, buffer, bufferOffset);
    // Serialize message field [brightness]
    bufferOffset = _serializer.int64(obj.brightness, buffer, bufferOffset);
    // Serialize message field [color_r]
    bufferOffset = _serializer.int64(obj.color_r, buffer, bufferOffset);
    // Serialize message field [color_g]
    bufferOffset = _serializer.int64(obj.color_g, buffer, bufferOffset);
    // Serialize message field [color_b]
    bufferOffset = _serializer.int64(obj.color_b, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type StripLight
    let len;
    let data = new StripLight(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [power]
    data.power = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [brightness]
    data.brightness = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [color_r]
    data.color_r = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [color_g]
    data.color_g = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [color_b]
    data.color_b = _deserializer.int64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 33;
  }

  static datatype() {
    // Returns string type for a message object
    return 'switchbot_ros/StripLight';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1385094b74c2f4366142c64abf86da06';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header  header       # timestamp
    
    bool    power        # ON/OFF state True/False
    
    int64   brightness   # the brightness value, range from 1 to 100
    int64   color_r      # Red   color value 0-255
    int64   color_g      # Green color value 0-255
    int64   color_b      # Blue  color value 0-255
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new StripLight(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.power !== undefined) {
      resolved.power = msg.power;
    }
    else {
      resolved.power = false
    }

    if (msg.brightness !== undefined) {
      resolved.brightness = msg.brightness;
    }
    else {
      resolved.brightness = 0
    }

    if (msg.color_r !== undefined) {
      resolved.color_r = msg.color_r;
    }
    else {
      resolved.color_r = 0
    }

    if (msg.color_g !== undefined) {
      resolved.color_g = msg.color_g;
    }
    else {
      resolved.color_g = 0
    }

    if (msg.color_b !== undefined) {
      resolved.color_b = msg.color_b;
    }
    else {
      resolved.color_b = 0
    }

    return resolved;
    }
};

module.exports = StripLight;
