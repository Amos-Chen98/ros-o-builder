
"use strict";

let SoundRequestActionFeedback = require('./SoundRequestActionFeedback.js');
let SoundRequestActionGoal = require('./SoundRequestActionGoal.js');
let SoundRequestResult = require('./SoundRequestResult.js');
let SoundRequestFeedback = require('./SoundRequestFeedback.js');
let SoundRequestActionResult = require('./SoundRequestActionResult.js');
let SoundRequestGoal = require('./SoundRequestGoal.js');
let SoundRequestAction = require('./SoundRequestAction.js');
let SoundRequest = require('./SoundRequest.js');

module.exports = {
  SoundRequestActionFeedback: SoundRequestActionFeedback,
  SoundRequestActionGoal: SoundRequestActionGoal,
  SoundRequestResult: SoundRequestResult,
  SoundRequestFeedback: SoundRequestFeedback,
  SoundRequestActionResult: SoundRequestActionResult,
  SoundRequestGoal: SoundRequestGoal,
  SoundRequestAction: SoundRequestAction,
  SoundRequest: SoundRequest,
};
