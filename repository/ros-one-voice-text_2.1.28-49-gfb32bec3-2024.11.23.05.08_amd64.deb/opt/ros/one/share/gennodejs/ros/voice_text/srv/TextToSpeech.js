// Auto-generated. Do not edit!

// (in-package voice_text.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class TextToSpeechRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.text_path = null;
      this.wave_path = null;
    }
    else {
      if (initObj.hasOwnProperty('text_path')) {
        this.text_path = initObj.text_path
      }
      else {
        this.text_path = '';
      }
      if (initObj.hasOwnProperty('wave_path')) {
        this.wave_path = initObj.wave_path
      }
      else {
        this.wave_path = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TextToSpeechRequest
    // Serialize message field [text_path]
    bufferOffset = _serializer.string(obj.text_path, buffer, bufferOffset);
    // Serialize message field [wave_path]
    bufferOffset = _serializer.string(obj.wave_path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TextToSpeechRequest
    let len;
    let data = new TextToSpeechRequest(null);
    // Deserialize message field [text_path]
    data.text_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [wave_path]
    data.wave_path = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.text_path);
    length += _getByteLength(object.wave_path);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'voice_text/TextToSpeechRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2313d9c56eb0e0571a953bf2b40316f4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string text_path
    string wave_path
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TextToSpeechRequest(null);
    if (msg.text_path !== undefined) {
      resolved.text_path = msg.text_path;
    }
    else {
      resolved.text_path = ''
    }

    if (msg.wave_path !== undefined) {
      resolved.wave_path = msg.wave_path;
    }
    else {
      resolved.wave_path = ''
    }

    return resolved;
    }
};

class TextToSpeechResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ok = null;
    }
    else {
      if (initObj.hasOwnProperty('ok')) {
        this.ok = initObj.ok
      }
      else {
        this.ok = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TextToSpeechResponse
    // Serialize message field [ok]
    bufferOffset = _serializer.bool(obj.ok, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TextToSpeechResponse
    let len;
    let data = new TextToSpeechResponse(null);
    // Deserialize message field [ok]
    data.ok = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'voice_text/TextToSpeechResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6f6da3883749771fac40d6deb24a8c02';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool ok
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TextToSpeechResponse(null);
    if (msg.ok !== undefined) {
      resolved.ok = msg.ok;
    }
    else {
      resolved.ok = false
    }

    return resolved;
    }
};

module.exports = {
  Request: TextToSpeechRequest,
  Response: TextToSpeechResponse,
  md5sum() { return 'cb72e53809c765fb76bd396201ead5a4'; },
  datatype() { return 'voice_text/TextToSpeech'; }
};
