
"use strict";

let MongoQuerywithProjectionMsg = require('./MongoQuerywithProjectionMsg.js')
let MongoUpdateMsg = require('./MongoUpdateMsg.js')
let MongoInsertMsg = require('./MongoInsertMsg.js')
let MongoDeleteMsg = require('./MongoDeleteMsg.js')
let MongoQueryMsg = require('./MongoQueryMsg.js')

module.exports = {
  MongoQuerywithProjectionMsg: MongoQuerywithProjectionMsg,
  MongoUpdateMsg: MongoUpdateMsg,
  MongoInsertMsg: MongoInsertMsg,
  MongoDeleteMsg: MongoDeleteMsg,
  MongoQueryMsg: MongoQueryMsg,
};
