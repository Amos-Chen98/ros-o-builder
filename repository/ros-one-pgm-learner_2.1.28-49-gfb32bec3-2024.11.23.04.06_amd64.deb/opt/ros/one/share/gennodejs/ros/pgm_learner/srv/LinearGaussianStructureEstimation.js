// Auto-generated. Do not edit!

// (in-package pgm_learner.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let LinearGaussianGraphState = require('../msg/LinearGaussianGraphState.js');

//-----------------------------------------------------------

let GraphStructure = require('../msg/GraphStructure.js');

//-----------------------------------------------------------

class LinearGaussianStructureEstimationRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.states = null;
      this.pvalparam = null;
      this.bins = null;
      this.indegree = null;
    }
    else {
      if (initObj.hasOwnProperty('states')) {
        this.states = initObj.states
      }
      else {
        this.states = [];
      }
      if (initObj.hasOwnProperty('pvalparam')) {
        this.pvalparam = initObj.pvalparam
      }
      else {
        this.pvalparam = 0.0;
      }
      if (initObj.hasOwnProperty('bins')) {
        this.bins = initObj.bins
      }
      else {
        this.bins = 0;
      }
      if (initObj.hasOwnProperty('indegree')) {
        this.indegree = initObj.indegree
      }
      else {
        this.indegree = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LinearGaussianStructureEstimationRequest
    // Serialize message field [states]
    // Serialize the length for message field [states]
    bufferOffset = _serializer.uint32(obj.states.length, buffer, bufferOffset);
    obj.states.forEach((val) => {
      bufferOffset = LinearGaussianGraphState.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [pvalparam]
    bufferOffset = _serializer.float64(obj.pvalparam, buffer, bufferOffset);
    // Serialize message field [bins]
    bufferOffset = _serializer.uint16(obj.bins, buffer, bufferOffset);
    // Serialize message field [indegree]
    bufferOffset = _serializer.uint16(obj.indegree, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LinearGaussianStructureEstimationRequest
    let len;
    let data = new LinearGaussianStructureEstimationRequest(null);
    // Deserialize message field [states]
    // Deserialize array length for message field [states]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.states = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.states[i] = LinearGaussianGraphState.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [pvalparam]
    data.pvalparam = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [bins]
    data.bins = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [indegree]
    data.indegree = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.states.forEach((val) => {
      length += LinearGaussianGraphState.getMessageSize(val);
    });
    return length + 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pgm_learner/LinearGaussianStructureEstimationRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e41b3446d42945de0248091da9c31f56';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    pgm_learner/LinearGaussianGraphState[] states # trial data
    float64 pvalparam # optional
    uint16 bins # optional
    uint16 indegree # optional
    
    ================================================================================
    MSG: pgm_learner/LinearGaussianGraphState
    pgm_learner/LinearGaussianNodeState[] node_states
    
    ================================================================================
    MSG: pgm_learner/LinearGaussianNodeState
    string node
    float32 state
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LinearGaussianStructureEstimationRequest(null);
    if (msg.states !== undefined) {
      resolved.states = new Array(msg.states.length);
      for (let i = 0; i < resolved.states.length; ++i) {
        resolved.states[i] = LinearGaussianGraphState.Resolve(msg.states[i]);
      }
    }
    else {
      resolved.states = []
    }

    if (msg.pvalparam !== undefined) {
      resolved.pvalparam = msg.pvalparam;
    }
    else {
      resolved.pvalparam = 0.0
    }

    if (msg.bins !== undefined) {
      resolved.bins = msg.bins;
    }
    else {
      resolved.bins = 0
    }

    if (msg.indegree !== undefined) {
      resolved.indegree = msg.indegree;
    }
    else {
      resolved.indegree = 0
    }

    return resolved;
    }
};

class LinearGaussianStructureEstimationResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.graph = null;
    }
    else {
      if (initObj.hasOwnProperty('graph')) {
        this.graph = initObj.graph
      }
      else {
        this.graph = new GraphStructure();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LinearGaussianStructureEstimationResponse
    // Serialize message field [graph]
    bufferOffset = GraphStructure.serialize(obj.graph, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LinearGaussianStructureEstimationResponse
    let len;
    let data = new LinearGaussianStructureEstimationResponse(null);
    // Deserialize message field [graph]
    data.graph = GraphStructure.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += GraphStructure.getMessageSize(object.graph);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pgm_learner/LinearGaussianStructureEstimationResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b84752916d49330453f083c59f6f9bc4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    pgm_learner/GraphStructure graph # structure of network
    
    
    ================================================================================
    MSG: pgm_learner/GraphStructure
    string[] nodes
    pgm_learner/GraphEdge[] edges
    
    ================================================================================
    MSG: pgm_learner/GraphEdge
    string node_from
    string node_to
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LinearGaussianStructureEstimationResponse(null);
    if (msg.graph !== undefined) {
      resolved.graph = GraphStructure.Resolve(msg.graph)
    }
    else {
      resolved.graph = new GraphStructure()
    }

    return resolved;
    }
};

module.exports = {
  Request: LinearGaussianStructureEstimationRequest,
  Response: LinearGaussianStructureEstimationResponse,
  md5sum() { return '1672c2df657722c2698213e54a484e74'; },
  datatype() { return 'pgm_learner/LinearGaussianStructureEstimation'; }
};
