// Auto-generated. Do not edit!

// (in-package pgm_learner.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class GraphEdge {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.node_from = null;
      this.node_to = null;
    }
    else {
      if (initObj.hasOwnProperty('node_from')) {
        this.node_from = initObj.node_from
      }
      else {
        this.node_from = '';
      }
      if (initObj.hasOwnProperty('node_to')) {
        this.node_to = initObj.node_to
      }
      else {
        this.node_to = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GraphEdge
    // Serialize message field [node_from]
    bufferOffset = _serializer.string(obj.node_from, buffer, bufferOffset);
    // Serialize message field [node_to]
    bufferOffset = _serializer.string(obj.node_to, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GraphEdge
    let len;
    let data = new GraphEdge(null);
    // Deserialize message field [node_from]
    data.node_from = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [node_to]
    data.node_to = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.node_from);
    length += _getByteLength(object.node_to);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pgm_learner/GraphEdge';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0e8438c5349fda07e98ac2a93db05307';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string node_from
    string node_to
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GraphEdge(null);
    if (msg.node_from !== undefined) {
      resolved.node_from = msg.node_from;
    }
    else {
      resolved.node_from = ''
    }

    if (msg.node_to !== undefined) {
      resolved.node_to = msg.node_to;
    }
    else {
      resolved.node_to = ''
    }

    return resolved;
    }
};

module.exports = GraphEdge;
