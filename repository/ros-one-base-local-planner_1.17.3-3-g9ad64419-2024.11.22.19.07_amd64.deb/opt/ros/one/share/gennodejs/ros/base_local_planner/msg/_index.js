
"use strict";

let Position2DInt = require('./Position2DInt.js');

module.exports = {
  Position2DInt: Position2DInt,
};
