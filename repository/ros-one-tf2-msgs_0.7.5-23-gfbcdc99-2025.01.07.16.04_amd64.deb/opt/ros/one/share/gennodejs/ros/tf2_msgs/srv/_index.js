
"use strict";

let FrameGraph = require('./FrameGraph.js')

module.exports = {
  FrameGraph: FrameGraph,
};
