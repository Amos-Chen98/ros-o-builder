// Auto-generated. Do not edit!

// (in-package app_manager.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Icon = require('./Icon.js');

//-----------------------------------------------------------

class ExchangeApp {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.display_name = null;
      this.version = null;
      this.latest_version = null;
      this.description = null;
      this.icon = null;
      this.hidden = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('display_name')) {
        this.display_name = initObj.display_name
      }
      else {
        this.display_name = '';
      }
      if (initObj.hasOwnProperty('version')) {
        this.version = initObj.version
      }
      else {
        this.version = '';
      }
      if (initObj.hasOwnProperty('latest_version')) {
        this.latest_version = initObj.latest_version
      }
      else {
        this.latest_version = '';
      }
      if (initObj.hasOwnProperty('description')) {
        this.description = initObj.description
      }
      else {
        this.description = '';
      }
      if (initObj.hasOwnProperty('icon')) {
        this.icon = initObj.icon
      }
      else {
        this.icon = new Icon();
      }
      if (initObj.hasOwnProperty('hidden')) {
        this.hidden = initObj.hidden
      }
      else {
        this.hidden = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ExchangeApp
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [display_name]
    bufferOffset = _serializer.string(obj.display_name, buffer, bufferOffset);
    // Serialize message field [version]
    bufferOffset = _serializer.string(obj.version, buffer, bufferOffset);
    // Serialize message field [latest_version]
    bufferOffset = _serializer.string(obj.latest_version, buffer, bufferOffset);
    // Serialize message field [description]
    bufferOffset = _serializer.string(obj.description, buffer, bufferOffset);
    // Serialize message field [icon]
    bufferOffset = Icon.serialize(obj.icon, buffer, bufferOffset);
    // Serialize message field [hidden]
    bufferOffset = _serializer.bool(obj.hidden, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ExchangeApp
    let len;
    let data = new ExchangeApp(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [display_name]
    data.display_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [version]
    data.version = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [latest_version]
    data.latest_version = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [description]
    data.description = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [icon]
    data.icon = Icon.deserialize(buffer, bufferOffset);
    // Deserialize message field [hidden]
    data.hidden = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    length += _getByteLength(object.display_name);
    length += _getByteLength(object.version);
    length += _getByteLength(object.latest_version);
    length += _getByteLength(object.description);
    length += Icon.getMessageSize(object.icon);
    return length + 21;
  }

  static datatype() {
    // Returns string type for a message object
    return 'app_manager/ExchangeApp';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ccad20aa9f390121e44c61d218038d78';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # app name
    string name
    # user-friendly display name of application
    string display_name
    # the version of the package currently installed
    string version
    # latest version of the package avaliable
    string latest_version
    # the detailed description of the app
    string description
    # icon for showing app
    Icon icon
    # hidden apps are not show - used for cases where multiple apps are in a deb
    bool hidden
    ================================================================================
    MSG: app_manager/Icon
    # Image data format.  "jpeg" or "png"
    string format
    
    # Image data.
    uint8[] data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ExchangeApp(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.display_name !== undefined) {
      resolved.display_name = msg.display_name;
    }
    else {
      resolved.display_name = ''
    }

    if (msg.version !== undefined) {
      resolved.version = msg.version;
    }
    else {
      resolved.version = ''
    }

    if (msg.latest_version !== undefined) {
      resolved.latest_version = msg.latest_version;
    }
    else {
      resolved.latest_version = ''
    }

    if (msg.description !== undefined) {
      resolved.description = msg.description;
    }
    else {
      resolved.description = ''
    }

    if (msg.icon !== undefined) {
      resolved.icon = Icon.Resolve(msg.icon)
    }
    else {
      resolved.icon = new Icon()
    }

    if (msg.hidden !== undefined) {
      resolved.hidden = msg.hidden;
    }
    else {
      resolved.hidden = false
    }

    return resolved;
    }
};

module.exports = ExchangeApp;
