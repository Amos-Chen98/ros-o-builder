// Auto-generated. Do not edit!

// (in-package handeye.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class CalibrateHandEyeRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.setup = null;
      this.solver = null;
      this.effector_wrt_world = null;
      this.object_wrt_sensor = null;
    }
    else {
      if (initObj.hasOwnProperty('setup')) {
        this.setup = initObj.setup
      }
      else {
        this.setup = '';
      }
      if (initObj.hasOwnProperty('solver')) {
        this.solver = initObj.solver
      }
      else {
        this.solver = '';
      }
      if (initObj.hasOwnProperty('effector_wrt_world')) {
        this.effector_wrt_world = initObj.effector_wrt_world
      }
      else {
        this.effector_wrt_world = new geometry_msgs.msg.PoseArray();
      }
      if (initObj.hasOwnProperty('object_wrt_sensor')) {
        this.object_wrt_sensor = initObj.object_wrt_sensor
      }
      else {
        this.object_wrt_sensor = new geometry_msgs.msg.PoseArray();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CalibrateHandEyeRequest
    // Serialize message field [setup]
    bufferOffset = _serializer.string(obj.setup, buffer, bufferOffset);
    // Serialize message field [solver]
    bufferOffset = _serializer.string(obj.solver, buffer, bufferOffset);
    // Serialize message field [effector_wrt_world]
    bufferOffset = geometry_msgs.msg.PoseArray.serialize(obj.effector_wrt_world, buffer, bufferOffset);
    // Serialize message field [object_wrt_sensor]
    bufferOffset = geometry_msgs.msg.PoseArray.serialize(obj.object_wrt_sensor, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CalibrateHandEyeRequest
    let len;
    let data = new CalibrateHandEyeRequest(null);
    // Deserialize message field [setup]
    data.setup = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [solver]
    data.solver = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [effector_wrt_world]
    data.effector_wrt_world = geometry_msgs.msg.PoseArray.deserialize(buffer, bufferOffset);
    // Deserialize message field [object_wrt_sensor]
    data.object_wrt_sensor = geometry_msgs.msg.PoseArray.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.setup);
    length += _getByteLength(object.solver);
    length += geometry_msgs.msg.PoseArray.getMessageSize(object.effector_wrt_world);
    length += geometry_msgs.msg.PoseArray.getMessageSize(object.object_wrt_sensor);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'handeye/CalibrateHandEyeRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9452c7113df2fa7160fa51c55eef0fd7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string                    setup
    string                    solver
    geometry_msgs/PoseArray   effector_wrt_world
    geometry_msgs/PoseArray   object_wrt_sensor
    
    ================================================================================
    MSG: geometry_msgs/PoseArray
    # An array of poses with a header for global reference.
    
    Header header
    
    Pose[] poses
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CalibrateHandEyeRequest(null);
    if (msg.setup !== undefined) {
      resolved.setup = msg.setup;
    }
    else {
      resolved.setup = ''
    }

    if (msg.solver !== undefined) {
      resolved.solver = msg.solver;
    }
    else {
      resolved.solver = ''
    }

    if (msg.effector_wrt_world !== undefined) {
      resolved.effector_wrt_world = geometry_msgs.msg.PoseArray.Resolve(msg.effector_wrt_world)
    }
    else {
      resolved.effector_wrt_world = new geometry_msgs.msg.PoseArray()
    }

    if (msg.object_wrt_sensor !== undefined) {
      resolved.object_wrt_sensor = geometry_msgs.msg.PoseArray.Resolve(msg.object_wrt_sensor)
    }
    else {
      resolved.object_wrt_sensor = new geometry_msgs.msg.PoseArray()
    }

    return resolved;
    }
};

class CalibrateHandEyeResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.sensor_frame = null;
      this.rotation_rmse = null;
      this.translation_rmse = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('sensor_frame')) {
        this.sensor_frame = initObj.sensor_frame
      }
      else {
        this.sensor_frame = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('rotation_rmse')) {
        this.rotation_rmse = initObj.rotation_rmse
      }
      else {
        this.rotation_rmse = 0.0;
      }
      if (initObj.hasOwnProperty('translation_rmse')) {
        this.translation_rmse = initObj.translation_rmse
      }
      else {
        this.translation_rmse = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CalibrateHandEyeResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [sensor_frame]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.sensor_frame, buffer, bufferOffset);
    // Serialize message field [rotation_rmse]
    bufferOffset = _serializer.float64(obj.rotation_rmse, buffer, bufferOffset);
    // Serialize message field [translation_rmse]
    bufferOffset = _serializer.float64(obj.translation_rmse, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CalibrateHandEyeResponse
    let len;
    let data = new CalibrateHandEyeResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [sensor_frame]
    data.sensor_frame = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [rotation_rmse]
    data.rotation_rmse = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [translation_rmse]
    data.translation_rmse = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 73;
  }

  static datatype() {
    // Returns string type for a service object
    return 'handeye/CalibrateHandEyeResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a500c4ad906c1d8c5f99d37687460c1f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool                      success
    # For a Moving setup, sensor_frame contains:
    # The estimated pose between the sensor and the robot end-effector
    # For a Fixed setup, sensor_frame contains:
    # The estimated pose between the sensor and the world
    geometry_msgs/Pose        sensor_frame
    float64                   rotation_rmse
    float64                   translation_rmse
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CalibrateHandEyeResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.sensor_frame !== undefined) {
      resolved.sensor_frame = geometry_msgs.msg.Pose.Resolve(msg.sensor_frame)
    }
    else {
      resolved.sensor_frame = new geometry_msgs.msg.Pose()
    }

    if (msg.rotation_rmse !== undefined) {
      resolved.rotation_rmse = msg.rotation_rmse;
    }
    else {
      resolved.rotation_rmse = 0.0
    }

    if (msg.translation_rmse !== undefined) {
      resolved.translation_rmse = msg.translation_rmse;
    }
    else {
      resolved.translation_rmse = 0.0
    }

    return resolved;
    }
};

module.exports = {
  Request: CalibrateHandEyeRequest,
  Response: CalibrateHandEyeResponse,
  md5sum() { return '04f81db812e7be5af7dacdfd384d6a48'; },
  datatype() { return 'handeye/CalibrateHandEye'; }
};
