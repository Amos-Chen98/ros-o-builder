// Auto-generated. Do not edit!

// (in-package ethercat_hardware.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class MotorTemperature {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.winding_temperature = null;
      this.housing_temperature = null;
      this.ambient_temperature = null;
      this.heating_power = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('winding_temperature')) {
        this.winding_temperature = initObj.winding_temperature
      }
      else {
        this.winding_temperature = 0.0;
      }
      if (initObj.hasOwnProperty('housing_temperature')) {
        this.housing_temperature = initObj.housing_temperature
      }
      else {
        this.housing_temperature = 0.0;
      }
      if (initObj.hasOwnProperty('ambient_temperature')) {
        this.ambient_temperature = initObj.ambient_temperature
      }
      else {
        this.ambient_temperature = 0.0;
      }
      if (initObj.hasOwnProperty('heating_power')) {
        this.heating_power = initObj.heating_power
      }
      else {
        this.heating_power = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotorTemperature
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [winding_temperature]
    bufferOffset = _serializer.float64(obj.winding_temperature, buffer, bufferOffset);
    // Serialize message field [housing_temperature]
    bufferOffset = _serializer.float64(obj.housing_temperature, buffer, bufferOffset);
    // Serialize message field [ambient_temperature]
    bufferOffset = _serializer.float64(obj.ambient_temperature, buffer, bufferOffset);
    // Serialize message field [heating_power]
    bufferOffset = _serializer.float64(obj.heating_power, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotorTemperature
    let len;
    let data = new MotorTemperature(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [winding_temperature]
    data.winding_temperature = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [housing_temperature]
    data.housing_temperature = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [ambient_temperature]
    data.ambient_temperature = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [heating_power]
    data.heating_power = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 40;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ethercat_hardware/MotorTemperature';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd8c7239cd096d6f25b75bff6b63f2162';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Sample of motor heating information
    time    stamp
    float64 winding_temperature
    float64 housing_temperature
    float64 ambient_temperature
    float64 heating_power
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotorTemperature(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.winding_temperature !== undefined) {
      resolved.winding_temperature = msg.winding_temperature;
    }
    else {
      resolved.winding_temperature = 0.0
    }

    if (msg.housing_temperature !== undefined) {
      resolved.housing_temperature = msg.housing_temperature;
    }
    else {
      resolved.housing_temperature = 0.0
    }

    if (msg.ambient_temperature !== undefined) {
      resolved.ambient_temperature = msg.ambient_temperature;
    }
    else {
      resolved.ambient_temperature = 0.0
    }

    if (msg.heating_power !== undefined) {
      resolved.heating_power = msg.heating_power;
    }
    else {
      resolved.heating_power = 0.0
    }

    return resolved;
    }
};

module.exports = MotorTemperature;
