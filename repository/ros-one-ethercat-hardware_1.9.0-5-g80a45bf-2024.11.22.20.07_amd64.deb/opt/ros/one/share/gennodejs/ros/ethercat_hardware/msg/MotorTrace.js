// Auto-generated. Do not edit!

// (in-package ethercat_hardware.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let BoardInfo = require('./BoardInfo.js');
let ActuatorInfo = require('./ActuatorInfo.js');
let MotorTraceSample = require('./MotorTraceSample.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class MotorTrace {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.reason = null;
      this.board_info = null;
      this.actuator_info = null;
      this.samples = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('reason')) {
        this.reason = initObj.reason
      }
      else {
        this.reason = '';
      }
      if (initObj.hasOwnProperty('board_info')) {
        this.board_info = initObj.board_info
      }
      else {
        this.board_info = new BoardInfo();
      }
      if (initObj.hasOwnProperty('actuator_info')) {
        this.actuator_info = initObj.actuator_info
      }
      else {
        this.actuator_info = new ActuatorInfo();
      }
      if (initObj.hasOwnProperty('samples')) {
        this.samples = initObj.samples
      }
      else {
        this.samples = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotorTrace
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [reason]
    bufferOffset = _serializer.string(obj.reason, buffer, bufferOffset);
    // Serialize message field [board_info]
    bufferOffset = BoardInfo.serialize(obj.board_info, buffer, bufferOffset);
    // Serialize message field [actuator_info]
    bufferOffset = ActuatorInfo.serialize(obj.actuator_info, buffer, bufferOffset);
    // Serialize message field [samples]
    // Serialize the length for message field [samples]
    bufferOffset = _serializer.uint32(obj.samples.length, buffer, bufferOffset);
    obj.samples.forEach((val) => {
      bufferOffset = MotorTraceSample.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotorTrace
    let len;
    let data = new MotorTrace(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [reason]
    data.reason = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [board_info]
    data.board_info = BoardInfo.deserialize(buffer, bufferOffset);
    // Deserialize message field [actuator_info]
    data.actuator_info = ActuatorInfo.deserialize(buffer, bufferOffset);
    // Deserialize message field [samples]
    // Deserialize array length for message field [samples]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.samples = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.samples[i] = MotorTraceSample.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.reason);
    length += BoardInfo.getMessageSize(object.board_info);
    length += ActuatorInfo.getMessageSize(object.actuator_info);
    length += 125 * object.samples.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ethercat_hardware/MotorTrace';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ada0b8b7f00967d292bd5bb4f59d4bd8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    string reason
    ethercat_hardware/BoardInfo board_info
    ethercat_hardware/ActuatorInfo actuator_info
    ethercat_hardware/MotorTraceSample[] samples
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: ethercat_hardware/BoardInfo
    string description
    uint32 product_code
    uint32 pcb
    uint32 pca
    uint32 serial
    uint32 firmware_major
    uint32 firmware_minor
    float64 board_resistance
    float64 max_pwm_ratio
    float64 hw_max_current
    bool poor_measured_motor_voltage
    ================================================================================
    MSG: ethercat_hardware/ActuatorInfo
    uint32 id
    string name
    string robot_name
    string motor_make
    string motor_model
    float64 max_current
    float64 speed_constant
    float64 motor_resistance
    float64 motor_torque_constant
    float64 encoder_reduction
    float64 pulses_per_revolution
    ================================================================================
    MSG: ethercat_hardware/MotorTraceSample
    float64 timestamp
    bool    enabled
    float64 supply_voltage
    float64 measured_motor_voltage
    float64 programmed_pwm
    float64 executed_current
    float64 measured_current
    float64 velocity
    float64 encoder_position
    uint32  encoder_error_count
    float64 motor_voltage_error_limit
    float64 filtered_motor_voltage_error
    float64 filtered_abs_motor_voltage_error
    float64 filtered_measured_voltage_error
    float64 filtered_abs_measured_voltage_error
    float64 filtered_current_error
    float64 filtered_abs_current_error
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotorTrace(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.reason !== undefined) {
      resolved.reason = msg.reason;
    }
    else {
      resolved.reason = ''
    }

    if (msg.board_info !== undefined) {
      resolved.board_info = BoardInfo.Resolve(msg.board_info)
    }
    else {
      resolved.board_info = new BoardInfo()
    }

    if (msg.actuator_info !== undefined) {
      resolved.actuator_info = ActuatorInfo.Resolve(msg.actuator_info)
    }
    else {
      resolved.actuator_info = new ActuatorInfo()
    }

    if (msg.samples !== undefined) {
      resolved.samples = new Array(msg.samples.length);
      for (let i = 0; i < resolved.samples.length; ++i) {
        resolved.samples[i] = MotorTraceSample.Resolve(msg.samples[i]);
      }
    }
    else {
      resolved.samples = []
    }

    return resolved;
    }
};

module.exports = MotorTrace;
