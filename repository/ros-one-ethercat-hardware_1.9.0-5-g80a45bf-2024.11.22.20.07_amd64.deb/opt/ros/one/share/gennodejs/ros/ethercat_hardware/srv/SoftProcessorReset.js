// Auto-generated. Do not edit!

// (in-package ethercat_hardware.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SoftProcessorResetRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.actuator_name = null;
      this.processor_name = null;
    }
    else {
      if (initObj.hasOwnProperty('actuator_name')) {
        this.actuator_name = initObj.actuator_name
      }
      else {
        this.actuator_name = '';
      }
      if (initObj.hasOwnProperty('processor_name')) {
        this.processor_name = initObj.processor_name
      }
      else {
        this.processor_name = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SoftProcessorResetRequest
    // Serialize message field [actuator_name]
    bufferOffset = _serializer.string(obj.actuator_name, buffer, bufferOffset);
    // Serialize message field [processor_name]
    bufferOffset = _serializer.string(obj.processor_name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SoftProcessorResetRequest
    let len;
    let data = new SoftProcessorResetRequest(null);
    // Deserialize message field [actuator_name]
    data.actuator_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [processor_name]
    data.processor_name = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.actuator_name);
    length += _getByteLength(object.processor_name);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ethercat_hardware/SoftProcessorResetRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '777be25d71e9e85e62fa14223ffddb6b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string actuator_name     # name of actuator that soft-processor is part of (ex : r_gripper_motor)
    string processor_name    # name of soft-processor to soft-reset, 
                             # certain devices may have more than one soft-processor
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SoftProcessorResetRequest(null);
    if (msg.actuator_name !== undefined) {
      resolved.actuator_name = msg.actuator_name;
    }
    else {
      resolved.actuator_name = ''
    }

    if (msg.processor_name !== undefined) {
      resolved.processor_name = msg.processor_name;
    }
    else {
      resolved.processor_name = ''
    }

    return resolved;
    }
};

class SoftProcessorResetResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.error_msg = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('error_msg')) {
        this.error_msg = initObj.error_msg
      }
      else {
        this.error_msg = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SoftProcessorResetResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [error_msg]
    bufferOffset = _serializer.string(obj.error_msg, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SoftProcessorResetResponse
    let len;
    let data = new SoftProcessorResetResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_msg]
    data.error_msg = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.error_msg);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ethercat_hardware/SoftProcessorResetResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd006c48be24db1173a071ca9af4c8179';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success             # true if processor was successfully reset
    string error_msg         # descriptive error message if call was not successful
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SoftProcessorResetResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.error_msg !== undefined) {
      resolved.error_msg = msg.error_msg;
    }
    else {
      resolved.error_msg = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SoftProcessorResetRequest,
  Response: SoftProcessorResetResponse,
  md5sum() { return '338c1a9d2fcf7479cddb1ea63dbc8af9'; },
  datatype() { return 'ethercat_hardware/SoftProcessorReset'; }
};
