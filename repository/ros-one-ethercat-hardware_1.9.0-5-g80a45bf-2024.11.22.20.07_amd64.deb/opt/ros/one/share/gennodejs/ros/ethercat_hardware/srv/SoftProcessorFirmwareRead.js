// Auto-generated. Do not edit!

// (in-package ethercat_hardware.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SoftProcessorFirmwareReadRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.actuator_name = null;
      this.processor_name = null;
    }
    else {
      if (initObj.hasOwnProperty('actuator_name')) {
        this.actuator_name = initObj.actuator_name
      }
      else {
        this.actuator_name = '';
      }
      if (initObj.hasOwnProperty('processor_name')) {
        this.processor_name = initObj.processor_name
      }
      else {
        this.processor_name = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SoftProcessorFirmwareReadRequest
    // Serialize message field [actuator_name]
    bufferOffset = _serializer.string(obj.actuator_name, buffer, bufferOffset);
    // Serialize message field [processor_name]
    bufferOffset = _serializer.string(obj.processor_name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SoftProcessorFirmwareReadRequest
    let len;
    let data = new SoftProcessorFirmwareReadRequest(null);
    // Deserialize message field [actuator_name]
    data.actuator_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [processor_name]
    data.processor_name = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.actuator_name);
    length += _getByteLength(object.processor_name);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ethercat_hardware/SoftProcessorFirmwareReadRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '777be25d71e9e85e62fa14223ffddb6b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string actuator_name     # name of actuator that soft-processor is part of (ex : r_gripper_motor)
    string processor_name    # name of soft-processor to firmware to read
                             # certain actuators may have more than one soft-processor (ex : accel, pressure)
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SoftProcessorFirmwareReadRequest(null);
    if (msg.actuator_name !== undefined) {
      resolved.actuator_name = msg.actuator_name;
    }
    else {
      resolved.actuator_name = ''
    }

    if (msg.processor_name !== undefined) {
      resolved.processor_name = msg.processor_name;
    }
    else {
      resolved.processor_name = ''
    }

    return resolved;
    }
};

class SoftProcessorFirmwareReadResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.error_msg = null;
      this.instructions = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('error_msg')) {
        this.error_msg = initObj.error_msg
      }
      else {
        this.error_msg = '';
      }
      if (initObj.hasOwnProperty('instructions')) {
        this.instructions = initObj.instructions
      }
      else {
        this.instructions = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SoftProcessorFirmwareReadResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [error_msg]
    bufferOffset = _serializer.string(obj.error_msg, buffer, bufferOffset);
    // Serialize message field [instructions]
    bufferOffset = _arraySerializer.uint32(obj.instructions, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SoftProcessorFirmwareReadResponse
    let len;
    let data = new SoftProcessorFirmwareReadResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_msg]
    data.error_msg = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [instructions]
    data.instructions = _arrayDeserializer.uint32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.error_msg);
    length += 4 * object.instructions.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ethercat_hardware/SoftProcessorFirmwareReadResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd36ea5e74d6ac75d45ab5ae553b4d4e6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success             # true if firmware was successfully read from device
    string error_msg         # descriptive error message if call was not successful
    uint32[] instructions    # list of firmware binary instructions.  
                             # not all soft-processors instructions use all 32bits for each instruction
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SoftProcessorFirmwareReadResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.error_msg !== undefined) {
      resolved.error_msg = msg.error_msg;
    }
    else {
      resolved.error_msg = ''
    }

    if (msg.instructions !== undefined) {
      resolved.instructions = msg.instructions;
    }
    else {
      resolved.instructions = []
    }

    return resolved;
    }
};

module.exports = {
  Request: SoftProcessorFirmwareReadRequest,
  Response: SoftProcessorFirmwareReadResponse,
  md5sum() { return '52ad83cdf3a5cf0a74166c7d411fc0aa'; },
  datatype() { return 'ethercat_hardware/SoftProcessorFirmwareRead'; }
};
