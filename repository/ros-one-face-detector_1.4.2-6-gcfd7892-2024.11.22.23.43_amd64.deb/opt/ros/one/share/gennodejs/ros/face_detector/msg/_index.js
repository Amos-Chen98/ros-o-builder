
"use strict";

let FaceDetectorActionFeedback = require('./FaceDetectorActionFeedback.js');
let FaceDetectorActionResult = require('./FaceDetectorActionResult.js');
let FaceDetectorActionGoal = require('./FaceDetectorActionGoal.js');
let FaceDetectorFeedback = require('./FaceDetectorFeedback.js');
let FaceDetectorResult = require('./FaceDetectorResult.js');
let FaceDetectorAction = require('./FaceDetectorAction.js');
let FaceDetectorGoal = require('./FaceDetectorGoal.js');

module.exports = {
  FaceDetectorActionFeedback: FaceDetectorActionFeedback,
  FaceDetectorActionResult: FaceDetectorActionResult,
  FaceDetectorActionGoal: FaceDetectorActionGoal,
  FaceDetectorFeedback: FaceDetectorFeedback,
  FaceDetectorResult: FaceDetectorResult,
  FaceDetectorAction: FaceDetectorAction,
  FaceDetectorGoal: FaceDetectorGoal,
};
