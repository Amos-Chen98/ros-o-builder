
"use strict";

let SnapFootPrint = require('./SnapFootPrint.js')
let MarkerSetPose = require('./MarkerSetPose.js')
let GetTransformableMarkerExistence = require('./GetTransformableMarkerExistence.js')
let GetMarkerDimensions = require('./GetMarkerDimensions.js')
let SetHeuristic = require('./SetHeuristic.js')
let SetParentMarker = require('./SetParentMarker.js')
let GetTransformableMarkerColor = require('./GetTransformableMarkerColor.js')
let SetTransformableMarkerFocus = require('./SetTransformableMarkerFocus.js')
let RemoveParentMarker = require('./RemoveParentMarker.js')
let IndexRequest = require('./IndexRequest.js')
let GetType = require('./GetType.js')
let GetTransformableMarkerFocus = require('./GetTransformableMarkerFocus.js')
let SetMarkerDimensions = require('./SetMarkerDimensions.js')
let GetTransformableMarkerPose = require('./GetTransformableMarkerPose.js')
let SetPose = require('./SetPose.js')
let SetTransformableMarkerColor = require('./SetTransformableMarkerColor.js')
let GetJointState = require('./GetJointState.js')
let SetTransformableMarkerPose = require('./SetTransformableMarkerPose.js')

module.exports = {
  SnapFootPrint: SnapFootPrint,
  MarkerSetPose: MarkerSetPose,
  GetTransformableMarkerExistence: GetTransformableMarkerExistence,
  GetMarkerDimensions: GetMarkerDimensions,
  SetHeuristic: SetHeuristic,
  SetParentMarker: SetParentMarker,
  GetTransformableMarkerColor: GetTransformableMarkerColor,
  SetTransformableMarkerFocus: SetTransformableMarkerFocus,
  RemoveParentMarker: RemoveParentMarker,
  IndexRequest: IndexRequest,
  GetType: GetType,
  GetTransformableMarkerFocus: GetTransformableMarkerFocus,
  SetMarkerDimensions: SetMarkerDimensions,
  GetTransformableMarkerPose: GetTransformableMarkerPose,
  SetPose: SetPose,
  SetTransformableMarkerColor: SetTransformableMarkerColor,
  GetJointState: GetJointState,
  SetTransformableMarkerPose: SetTransformableMarkerPose,
};
