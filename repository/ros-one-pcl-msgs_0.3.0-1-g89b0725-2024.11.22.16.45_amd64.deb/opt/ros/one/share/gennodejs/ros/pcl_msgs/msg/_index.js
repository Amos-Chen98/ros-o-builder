
"use strict";

let PolygonMesh = require('./PolygonMesh.js');
let Vertices = require('./Vertices.js');
let ModelCoefficients = require('./ModelCoefficients.js');
let PointIndices = require('./PointIndices.js');

module.exports = {
  PolygonMesh: PolygonMesh,
  Vertices: Vertices,
  ModelCoefficients: ModelCoefficients,
  PointIndices: PointIndices,
};
