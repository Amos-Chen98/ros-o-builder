
"use strict";

let SetPayload = require('./SetPayload.js')
let SetAnalogOutput = require('./SetAnalogOutput.js')
let SetIO = require('./SetIO.js')
let GetRobotSoftwareVersion = require('./GetRobotSoftwareVersion.js')
let SetSpeedSliderFraction = require('./SetSpeedSliderFraction.js')

module.exports = {
  SetPayload: SetPayload,
  SetAnalogOutput: SetAnalogOutput,
  SetIO: SetIO,
  GetRobotSoftwareVersion: GetRobotSoftwareVersion,
  SetSpeedSliderFraction: SetSpeedSliderFraction,
};
