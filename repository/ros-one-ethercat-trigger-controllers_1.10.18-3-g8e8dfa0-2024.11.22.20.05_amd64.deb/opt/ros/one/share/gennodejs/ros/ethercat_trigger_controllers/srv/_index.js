
"use strict";

let SetMultiWaveform = require('./SetMultiWaveform.js')
let SetWaveform = require('./SetWaveform.js')

module.exports = {
  SetMultiWaveform: SetMultiWaveform,
  SetWaveform: SetWaveform,
};
