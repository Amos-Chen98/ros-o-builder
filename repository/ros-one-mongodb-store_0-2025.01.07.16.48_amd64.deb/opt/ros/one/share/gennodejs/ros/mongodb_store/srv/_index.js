
"use strict";

let SetParam = require('./SetParam.js')
let MongoFind = require('./MongoFind.js')
let GetParam = require('./GetParam.js')
let MongoInsert = require('./MongoInsert.js')
let MongoUpdate = require('./MongoUpdate.js')

module.exports = {
  SetParam: SetParam,
  MongoFind: MongoFind,
  GetParam: GetParam,
  MongoInsert: MongoInsert,
  MongoUpdate: MongoUpdate,
};
