// Auto-generated. Do not edit!

// (in-package view_controller_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class CameraMovement {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.eye = null;
      this.focus = null;
      this.up = null;
      this.transition_duration = null;
      this.interpolation_speed = null;
    }
    else {
      if (initObj.hasOwnProperty('eye')) {
        this.eye = initObj.eye
      }
      else {
        this.eye = new geometry_msgs.msg.PointStamped();
      }
      if (initObj.hasOwnProperty('focus')) {
        this.focus = initObj.focus
      }
      else {
        this.focus = new geometry_msgs.msg.PointStamped();
      }
      if (initObj.hasOwnProperty('up')) {
        this.up = initObj.up
      }
      else {
        this.up = new geometry_msgs.msg.Vector3Stamped();
      }
      if (initObj.hasOwnProperty('transition_duration')) {
        this.transition_duration = initObj.transition_duration
      }
      else {
        this.transition_duration = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('interpolation_speed')) {
        this.interpolation_speed = initObj.interpolation_speed
      }
      else {
        this.interpolation_speed = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CameraMovement
    // Serialize message field [eye]
    bufferOffset = geometry_msgs.msg.PointStamped.serialize(obj.eye, buffer, bufferOffset);
    // Serialize message field [focus]
    bufferOffset = geometry_msgs.msg.PointStamped.serialize(obj.focus, buffer, bufferOffset);
    // Serialize message field [up]
    bufferOffset = geometry_msgs.msg.Vector3Stamped.serialize(obj.up, buffer, bufferOffset);
    // Serialize message field [transition_duration]
    bufferOffset = _serializer.duration(obj.transition_duration, buffer, bufferOffset);
    // Serialize message field [interpolation_speed]
    bufferOffset = _serializer.uint8(obj.interpolation_speed, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CameraMovement
    let len;
    let data = new CameraMovement(null);
    // Deserialize message field [eye]
    data.eye = geometry_msgs.msg.PointStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [focus]
    data.focus = geometry_msgs.msg.PointStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [up]
    data.up = geometry_msgs.msg.Vector3Stamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [transition_duration]
    data.transition_duration = _deserializer.duration(buffer, bufferOffset);
    // Deserialize message field [interpolation_speed]
    data.interpolation_speed = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += geometry_msgs.msg.PointStamped.getMessageSize(object.eye);
    length += geometry_msgs.msg.PointStamped.getMessageSize(object.focus);
    length += geometry_msgs.msg.Vector3Stamped.getMessageSize(object.up);
    return length + 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'view_controller_msgs/CameraMovement';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fc7aac4a39426fb5e8b2dbb6e85bfc66';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # This message defines where to move a camera to and at which speeds.  
    
    # The target pose definition:
    
    # The frame-relative point to move the camera to.
    geometry_msgs/PointStamped eye
    
    # The frame-relative point for the focus (or pivot for an Orbit controller).
    # The camera points into the direction of the focus point at the end of the movement.
    geometry_msgs/PointStamped focus
    
    # The frame-relative vector that maps to "up" in the view plane.
    # In other words, a vector pointing to the top of the camera, in case you want to perform roll movements.
    geometry_msgs/Vector3Stamped up
    
    
    # Defines how long the transition from the current to the target camera pose should take.
    # Movements with a negative transition_duration will be ignored.
    duration transition_duration
    
    # The interpolation speed profile to use during this movement.
    uint8 interpolation_speed
    uint8 RISING    = 0 # Speed of the camera rises smoothly - resembles the first quarter of a sinus wave.
    uint8 DECLINING = 1 # Speed of the camera declines smoothly - resembles the second quarter of a sinus wave.
    uint8 FULL      = 2 # Camera is always at full speed - depending on transition_duration.
    uint8 WAVE      = 3 # RISING and DECLINING concatenated in one movement.
    
    ================================================================================
    MSG: geometry_msgs/PointStamped
    # This represents a Point with reference coordinate frame and timestamp
    Header header
    Point point
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Vector3Stamped
    # This represents a Vector3 with reference coordinate frame and timestamp
    Header header
    Vector3 vector
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CameraMovement(null);
    if (msg.eye !== undefined) {
      resolved.eye = geometry_msgs.msg.PointStamped.Resolve(msg.eye)
    }
    else {
      resolved.eye = new geometry_msgs.msg.PointStamped()
    }

    if (msg.focus !== undefined) {
      resolved.focus = geometry_msgs.msg.PointStamped.Resolve(msg.focus)
    }
    else {
      resolved.focus = new geometry_msgs.msg.PointStamped()
    }

    if (msg.up !== undefined) {
      resolved.up = geometry_msgs.msg.Vector3Stamped.Resolve(msg.up)
    }
    else {
      resolved.up = new geometry_msgs.msg.Vector3Stamped()
    }

    if (msg.transition_duration !== undefined) {
      resolved.transition_duration = msg.transition_duration;
    }
    else {
      resolved.transition_duration = {secs: 0, nsecs: 0}
    }

    if (msg.interpolation_speed !== undefined) {
      resolved.interpolation_speed = msg.interpolation_speed;
    }
    else {
      resolved.interpolation_speed = 0
    }

    return resolved;
    }
};

// Constants for message
CameraMovement.Constants = {
  RISING: 0,
  DECLINING: 1,
  FULL: 2,
  WAVE: 3,
}

module.exports = CameraMovement;
