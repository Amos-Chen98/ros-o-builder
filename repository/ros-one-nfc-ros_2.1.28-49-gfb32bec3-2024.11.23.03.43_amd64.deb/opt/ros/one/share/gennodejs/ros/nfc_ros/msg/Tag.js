// Auto-generated. Do not edit!

// (in-package nfc_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let NDEFRecord = require('./NDEFRecord.js');

//-----------------------------------------------------------

class Tag {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tag_type = null;
      this.ndef_records = null;
      this.identifier = null;
    }
    else {
      if (initObj.hasOwnProperty('tag_type')) {
        this.tag_type = initObj.tag_type
      }
      else {
        this.tag_type = 0;
      }
      if (initObj.hasOwnProperty('ndef_records')) {
        this.ndef_records = initObj.ndef_records
      }
      else {
        this.ndef_records = [];
      }
      if (initObj.hasOwnProperty('identifier')) {
        this.identifier = initObj.identifier
      }
      else {
        this.identifier = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Tag
    // Serialize message field [tag_type]
    bufferOffset = _serializer.int16(obj.tag_type, buffer, bufferOffset);
    // Serialize message field [ndef_records]
    // Serialize the length for message field [ndef_records]
    bufferOffset = _serializer.uint32(obj.ndef_records.length, buffer, bufferOffset);
    obj.ndef_records.forEach((val) => {
      bufferOffset = NDEFRecord.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [identifier]
    bufferOffset = _serializer.string(obj.identifier, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Tag
    let len;
    let data = new Tag(null);
    // Deserialize message field [tag_type]
    data.tag_type = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [ndef_records]
    // Deserialize array length for message field [ndef_records]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.ndef_records = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.ndef_records[i] = NDEFRecord.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [identifier]
    data.identifier = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.ndef_records.forEach((val) => {
      length += NDEFRecord.getMessageSize(val);
    });
    length += _getByteLength(object.identifier);
    return length + 10;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nfc_ros/Tag';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '36322935513001cbca4f6ccdd60cbada';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 NFC_TAG_TYPE1TAG=100
    
    # Type2 Tags
    int16 NFC_TAG_TYPE2TAG=200
    int16 NFC_TAG_TYPE2NXPMIFAREULTRALIGHT=201
    int16 NFC_TAG_TYPE2NXPMIFAREULTRALIGHTC=202
    int16 NFC_TAG_TYPE2NXPNTAG210=203
    int16 NFC_TAG_TYPE2NXPNTAG212=204
    int16 NFC_TAG_TYPE2NXPNTAG215=205
    int16 NFC_TAG_TYPE2NXPNTAG216=206
    int16 NFC_TAG_TYPE2NXPMIFAREULTRALIGHTEV1=207
    
    # Type3 Tags
    int16 NFC_TAG_TYPE3TAG=300
    int16 NFC_TAG_FelicaStandard=301
    int16 NFC_TAG_FelicaMobile=302
    int16 NFC_TAG_FelicaLite=303
    int16 NFC_TAG_FelicaLiteS=304
    int16 NFC_TAG_FelicaPlug=305
    
    # Type4 Tags
    int16 NFC_TAG_TYPE4TAG=400
    int16 NFC_TAG_TYPE4ATAG=401
    int16 NFC_TAG_TYPE4BTAG=402
    
    int16 tag_type
    NDEFRecord[] ndef_records
    string identifier
    
    ================================================================================
    MSG: nfc_ros/NDEFRecord
    string type
    string name
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Tag(null);
    if (msg.tag_type !== undefined) {
      resolved.tag_type = msg.tag_type;
    }
    else {
      resolved.tag_type = 0
    }

    if (msg.ndef_records !== undefined) {
      resolved.ndef_records = new Array(msg.ndef_records.length);
      for (let i = 0; i < resolved.ndef_records.length; ++i) {
        resolved.ndef_records[i] = NDEFRecord.Resolve(msg.ndef_records[i]);
      }
    }
    else {
      resolved.ndef_records = []
    }

    if (msg.identifier !== undefined) {
      resolved.identifier = msg.identifier;
    }
    else {
      resolved.identifier = ''
    }

    return resolved;
    }
};

// Constants for message
Tag.Constants = {
  NFC_TAG_TYPE1TAG: 100,
  NFC_TAG_TYPE2TAG: 200,
  NFC_TAG_TYPE2NXPMIFAREULTRALIGHT: 201,
  NFC_TAG_TYPE2NXPMIFAREULTRALIGHTC: 202,
  NFC_TAG_TYPE2NXPNTAG210: 203,
  NFC_TAG_TYPE2NXPNTAG212: 204,
  NFC_TAG_TYPE2NXPNTAG215: 205,
  NFC_TAG_TYPE2NXPNTAG216: 206,
  NFC_TAG_TYPE2NXPMIFAREULTRALIGHTEV1: 207,
  NFC_TAG_TYPE3TAG: 300,
  NFC_TAG_FELICASTANDARD: 301,
  NFC_TAG_FELICAMOBILE: 302,
  NFC_TAG_FELICALITE: 303,
  NFC_TAG_FELICALITES: 304,
  NFC_TAG_FELICAPLUG: 305,
  NFC_TAG_TYPE4TAG: 400,
  NFC_TAG_TYPE4ATAG: 401,
  NFC_TAG_TYPE4BTAG: 402,
}

module.exports = Tag;
