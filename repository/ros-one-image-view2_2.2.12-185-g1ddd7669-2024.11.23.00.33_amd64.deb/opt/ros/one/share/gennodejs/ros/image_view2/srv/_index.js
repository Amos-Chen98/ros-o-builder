
"use strict";

let ChangeMode = require('./ChangeMode.js')

module.exports = {
  ChangeMode: ChangeMode,
};
