
"use strict";

let PhraseRule = require('./PhraseRule.js');
let Vocabulary = require('./Vocabulary.js');
let SpeechRecognitionCandidates = require('./SpeechRecognitionCandidates.js');
let Grammar = require('./Grammar.js');

module.exports = {
  PhraseRule: PhraseRule,
  Vocabulary: Vocabulary,
  SpeechRecognitionCandidates: SpeechRecognitionCandidates,
  Grammar: Grammar,
};
