
"use strict";

let Query = require('./Query.js')
let YesNo = require('./YesNo.js')

module.exports = {
  Query: Query,
  YesNo: YesNo,
};
