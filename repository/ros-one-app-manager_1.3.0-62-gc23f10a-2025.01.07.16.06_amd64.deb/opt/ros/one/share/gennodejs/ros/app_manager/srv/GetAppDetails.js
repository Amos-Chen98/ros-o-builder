// Auto-generated. Do not edit!

// (in-package app_manager.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let ExchangeApp = require('../msg/ExchangeApp.js');

//-----------------------------------------------------------

class GetAppDetailsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetAppDetailsRequest
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetAppDetailsRequest
    let len;
    let data = new GetAppDetailsRequest(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'app_manager/GetAppDetailsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c1f3d28f1b044c871e6eff2e9fc3c667';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Name of the app to get details of
    string name 
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetAppDetailsRequest(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    return resolved;
    }
};

class GetAppDetailsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.app = null;
    }
    else {
      if (initObj.hasOwnProperty('app')) {
        this.app = initObj.app
      }
      else {
        this.app = new ExchangeApp();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetAppDetailsResponse
    // Serialize message field [app]
    bufferOffset = ExchangeApp.serialize(obj.app, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetAppDetailsResponse
    let len;
    let data = new GetAppDetailsResponse(null);
    // Deserialize message field [app]
    data.app = ExchangeApp.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += ExchangeApp.getMessageSize(object.app);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'app_manager/GetAppDetailsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '404cd76612a719d24ac22fba2d495de8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ExchangeApp app
    
    
    
    ================================================================================
    MSG: app_manager/ExchangeApp
    # app name
    string name
    # user-friendly display name of application
    string display_name
    # the version of the package currently installed
    string version
    # latest version of the package avaliable
    string latest_version
    # the detailed description of the app
    string description
    # icon for showing app
    Icon icon
    # hidden apps are not show - used for cases where multiple apps are in a deb
    bool hidden
    ================================================================================
    MSG: app_manager/Icon
    # Image data format.  "jpeg" or "png"
    string format
    
    # Image data.
    uint8[] data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetAppDetailsResponse(null);
    if (msg.app !== undefined) {
      resolved.app = ExchangeApp.Resolve(msg.app)
    }
    else {
      resolved.app = new ExchangeApp()
    }

    return resolved;
    }
};

module.exports = {
  Request: GetAppDetailsRequest,
  Response: GetAppDetailsResponse,
  md5sum() { return '982707be65dd9bb38c19f6e18cb18db5'; },
  datatype() { return 'app_manager/GetAppDetails'; }
};
