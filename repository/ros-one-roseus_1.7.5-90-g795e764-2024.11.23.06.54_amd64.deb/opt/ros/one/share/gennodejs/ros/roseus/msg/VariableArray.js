// Auto-generated. Do not edit!

// (in-package roseus.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class VariableArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.float32_data = null;
      this.float64_data = null;
      this.int16_data = null;
      this.int32_data = null;
      this.int64_data = null;
      this.int8_data = null;
      this.uint16_data = null;
      this.uint32_data = null;
      this.uint64_data = null;
      this.uint8_data = null;
      this.bool_data = null;
      this.time_data = null;
      this.duration_data = null;
      this.string_data = null;
    }
    else {
      if (initObj.hasOwnProperty('float32_data')) {
        this.float32_data = initObj.float32_data
      }
      else {
        this.float32_data = [];
      }
      if (initObj.hasOwnProperty('float64_data')) {
        this.float64_data = initObj.float64_data
      }
      else {
        this.float64_data = [];
      }
      if (initObj.hasOwnProperty('int16_data')) {
        this.int16_data = initObj.int16_data
      }
      else {
        this.int16_data = [];
      }
      if (initObj.hasOwnProperty('int32_data')) {
        this.int32_data = initObj.int32_data
      }
      else {
        this.int32_data = [];
      }
      if (initObj.hasOwnProperty('int64_data')) {
        this.int64_data = initObj.int64_data
      }
      else {
        this.int64_data = [];
      }
      if (initObj.hasOwnProperty('int8_data')) {
        this.int8_data = initObj.int8_data
      }
      else {
        this.int8_data = [];
      }
      if (initObj.hasOwnProperty('uint16_data')) {
        this.uint16_data = initObj.uint16_data
      }
      else {
        this.uint16_data = [];
      }
      if (initObj.hasOwnProperty('uint32_data')) {
        this.uint32_data = initObj.uint32_data
      }
      else {
        this.uint32_data = [];
      }
      if (initObj.hasOwnProperty('uint64_data')) {
        this.uint64_data = initObj.uint64_data
      }
      else {
        this.uint64_data = [];
      }
      if (initObj.hasOwnProperty('uint8_data')) {
        this.uint8_data = initObj.uint8_data
      }
      else {
        this.uint8_data = [];
      }
      if (initObj.hasOwnProperty('bool_data')) {
        this.bool_data = initObj.bool_data
      }
      else {
        this.bool_data = [];
      }
      if (initObj.hasOwnProperty('time_data')) {
        this.time_data = initObj.time_data
      }
      else {
        this.time_data = [];
      }
      if (initObj.hasOwnProperty('duration_data')) {
        this.duration_data = initObj.duration_data
      }
      else {
        this.duration_data = [];
      }
      if (initObj.hasOwnProperty('string_data')) {
        this.string_data = initObj.string_data
      }
      else {
        this.string_data = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type VariableArray
    // Serialize message field [float32_data]
    bufferOffset = _arraySerializer.float32(obj.float32_data, buffer, bufferOffset, null);
    // Serialize message field [float64_data]
    bufferOffset = _arraySerializer.float64(obj.float64_data, buffer, bufferOffset, null);
    // Serialize message field [int16_data]
    bufferOffset = _arraySerializer.int16(obj.int16_data, buffer, bufferOffset, null);
    // Serialize message field [int32_data]
    bufferOffset = _arraySerializer.int32(obj.int32_data, buffer, bufferOffset, null);
    // Serialize message field [int64_data]
    bufferOffset = _arraySerializer.int64(obj.int64_data, buffer, bufferOffset, null);
    // Serialize message field [int8_data]
    bufferOffset = _arraySerializer.int8(obj.int8_data, buffer, bufferOffset, null);
    // Serialize message field [uint16_data]
    bufferOffset = _arraySerializer.uint16(obj.uint16_data, buffer, bufferOffset, null);
    // Serialize message field [uint32_data]
    bufferOffset = _arraySerializer.uint32(obj.uint32_data, buffer, bufferOffset, null);
    // Serialize message field [uint64_data]
    bufferOffset = _arraySerializer.uint64(obj.uint64_data, buffer, bufferOffset, null);
    // Serialize message field [uint8_data]
    bufferOffset = _arraySerializer.uint8(obj.uint8_data, buffer, bufferOffset, null);
    // Serialize message field [bool_data]
    bufferOffset = _arraySerializer.bool(obj.bool_data, buffer, bufferOffset, null);
    // Serialize message field [time_data]
    bufferOffset = _arraySerializer.time(obj.time_data, buffer, bufferOffset, null);
    // Serialize message field [duration_data]
    bufferOffset = _arraySerializer.duration(obj.duration_data, buffer, bufferOffset, null);
    // Serialize message field [string_data]
    // Serialize the length for message field [string_data]
    bufferOffset = _serializer.uint32(obj.string_data.length, buffer, bufferOffset);
    obj.string_data.forEach((val) => {
      bufferOffset = std_msgs.msg.String.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type VariableArray
    let len;
    let data = new VariableArray(null);
    // Deserialize message field [float32_data]
    data.float32_data = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [float64_data]
    data.float64_data = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [int16_data]
    data.int16_data = _arrayDeserializer.int16(buffer, bufferOffset, null)
    // Deserialize message field [int32_data]
    data.int32_data = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [int64_data]
    data.int64_data = _arrayDeserializer.int64(buffer, bufferOffset, null)
    // Deserialize message field [int8_data]
    data.int8_data = _arrayDeserializer.int8(buffer, bufferOffset, null)
    // Deserialize message field [uint16_data]
    data.uint16_data = _arrayDeserializer.uint16(buffer, bufferOffset, null)
    // Deserialize message field [uint32_data]
    data.uint32_data = _arrayDeserializer.uint32(buffer, bufferOffset, null)
    // Deserialize message field [uint64_data]
    data.uint64_data = _arrayDeserializer.uint64(buffer, bufferOffset, null)
    // Deserialize message field [uint8_data]
    data.uint8_data = _arrayDeserializer.uint8(buffer, bufferOffset, null)
    // Deserialize message field [bool_data]
    data.bool_data = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [time_data]
    data.time_data = _arrayDeserializer.time(buffer, bufferOffset, null)
    // Deserialize message field [duration_data]
    data.duration_data = _arrayDeserializer.duration(buffer, bufferOffset, null)
    // Deserialize message field [string_data]
    // Deserialize array length for message field [string_data]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.string_data = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.string_data[i] = std_msgs.msg.String.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.float32_data.length;
    length += 8 * object.float64_data.length;
    length += 2 * object.int16_data.length;
    length += 4 * object.int32_data.length;
    length += 8 * object.int64_data.length;
    length += object.int8_data.length;
    length += 2 * object.uint16_data.length;
    length += 4 * object.uint32_data.length;
    length += 8 * object.uint64_data.length;
    length += object.uint8_data.length;
    length += object.bool_data.length;
    length += 8 * object.time_data.length;
    length += 8 * object.duration_data.length;
    object.string_data.forEach((val) => {
      length += std_msgs.msg.String.getMessageSize(val);
    });
    return length + 56;
  }

  static datatype() {
    // Returns string type for a message object
    return 'roseus/VariableArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'aebf8af723dcbdb6782481457d175157';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # This message is only for geneus test
    float32[]  float32_data
    float64[]  float64_data
      int16[]  int16_data
      int32[]  int32_data
      int64[]  int64_data
       int8[]  int8_data
     uint16[]  uint16_data
     uint32[]  uint32_data
     uint64[]  uint64_data
      uint8[]  uint8_data
       bool[]  bool_data
       time[]  time_data
    duration[]  duration_data
    std_msgs/String[] string_data
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new VariableArray(null);
    if (msg.float32_data !== undefined) {
      resolved.float32_data = msg.float32_data;
    }
    else {
      resolved.float32_data = []
    }

    if (msg.float64_data !== undefined) {
      resolved.float64_data = msg.float64_data;
    }
    else {
      resolved.float64_data = []
    }

    if (msg.int16_data !== undefined) {
      resolved.int16_data = msg.int16_data;
    }
    else {
      resolved.int16_data = []
    }

    if (msg.int32_data !== undefined) {
      resolved.int32_data = msg.int32_data;
    }
    else {
      resolved.int32_data = []
    }

    if (msg.int64_data !== undefined) {
      resolved.int64_data = msg.int64_data;
    }
    else {
      resolved.int64_data = []
    }

    if (msg.int8_data !== undefined) {
      resolved.int8_data = msg.int8_data;
    }
    else {
      resolved.int8_data = []
    }

    if (msg.uint16_data !== undefined) {
      resolved.uint16_data = msg.uint16_data;
    }
    else {
      resolved.uint16_data = []
    }

    if (msg.uint32_data !== undefined) {
      resolved.uint32_data = msg.uint32_data;
    }
    else {
      resolved.uint32_data = []
    }

    if (msg.uint64_data !== undefined) {
      resolved.uint64_data = msg.uint64_data;
    }
    else {
      resolved.uint64_data = []
    }

    if (msg.uint8_data !== undefined) {
      resolved.uint8_data = msg.uint8_data;
    }
    else {
      resolved.uint8_data = []
    }

    if (msg.bool_data !== undefined) {
      resolved.bool_data = msg.bool_data;
    }
    else {
      resolved.bool_data = []
    }

    if (msg.time_data !== undefined) {
      resolved.time_data = msg.time_data;
    }
    else {
      resolved.time_data = []
    }

    if (msg.duration_data !== undefined) {
      resolved.duration_data = msg.duration_data;
    }
    else {
      resolved.duration_data = []
    }

    if (msg.string_data !== undefined) {
      resolved.string_data = new Array(msg.string_data.length);
      for (let i = 0; i < resolved.string_data.length; ++i) {
        resolved.string_data[i] = std_msgs.msg.String.Resolve(msg.string_data[i]);
      }
    }
    else {
      resolved.string_data = []
    }

    return resolved;
    }
};

module.exports = VariableArray;
