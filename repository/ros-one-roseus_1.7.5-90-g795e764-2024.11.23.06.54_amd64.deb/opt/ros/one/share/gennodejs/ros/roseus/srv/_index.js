
"use strict";

let StringString = require('./StringString.js')
let AddTwoInts = require('./AddTwoInts.js')

module.exports = {
  StringString: StringString,
  AddTwoInts: AddTwoInts,
};
