
"use strict";

let AnalyzeSingleImage = require('./AnalyzeSingleImage.js')

module.exports = {
  AnalyzeSingleImage: AnalyzeSingleImage,
};
