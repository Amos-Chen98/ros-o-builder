
"use strict";

let ObjectRecognitionResult = require('./ObjectRecognitionResult.js');
let ObjectRecognitionActionFeedback = require('./ObjectRecognitionActionFeedback.js');
let ObjectRecognitionGoal = require('./ObjectRecognitionGoal.js');
let ObjectRecognitionActionGoal = require('./ObjectRecognitionActionGoal.js');
let ObjectRecognitionActionResult = require('./ObjectRecognitionActionResult.js');
let ObjectRecognitionFeedback = require('./ObjectRecognitionFeedback.js');
let ObjectRecognitionAction = require('./ObjectRecognitionAction.js');
let RecognizedObjectArray = require('./RecognizedObjectArray.js');
let Table = require('./Table.js');
let RecognizedObject = require('./RecognizedObject.js');
let TableArray = require('./TableArray.js');
let ObjectType = require('./ObjectType.js');
let ObjectInformation = require('./ObjectInformation.js');

module.exports = {
  ObjectRecognitionResult: ObjectRecognitionResult,
  ObjectRecognitionActionFeedback: ObjectRecognitionActionFeedback,
  ObjectRecognitionGoal: ObjectRecognitionGoal,
  ObjectRecognitionActionGoal: ObjectRecognitionActionGoal,
  ObjectRecognitionActionResult: ObjectRecognitionActionResult,
  ObjectRecognitionFeedback: ObjectRecognitionFeedback,
  ObjectRecognitionAction: ObjectRecognitionAction,
  RecognizedObjectArray: RecognizedObjectArray,
  Table: Table,
  RecognizedObject: RecognizedObject,
  TableArray: TableArray,
  ObjectType: ObjectType,
  ObjectInformation: ObjectInformation,
};
