
"use strict";

let TopicInfo = require('./TopicInfo.js');

module.exports = {
  TopicInfo: TopicInfo,
};
